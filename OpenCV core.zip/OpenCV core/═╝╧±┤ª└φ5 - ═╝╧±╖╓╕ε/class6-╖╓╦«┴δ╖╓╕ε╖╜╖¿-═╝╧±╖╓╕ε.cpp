//分水岭分割方法 - 图像分割
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace cv::ml;
using namespace std;
Mat watershedCluster(Mat& image,int& Num_Comp);
void Create_Display_Segments(Mat& markers, int numSegment);
int main(int argc, char** argv) {
    Mat src = imread("D:\\OpenCV core\\class1\\toux.jpg");
    if(src.empty()) {
        printf("the image is empty");
        return -1;
    }
    namedWindow("src",WINDOW_AUTOSIZE);
    imshow("src",src);

    int Num_Segment;
    Mat Markers = watershedCluster(src,Num_Segment);
    Create_Display_Segments(Markers,Num_Segment);
    waitKey(0);
    return 0;
}
Mat watershedCluster(Mat& image,int& Num_Comp)   //分水岭分割
{
//  二值化
    Mat gray,binary;
    cvtColor(image,gray,CV_BGR2GRAY);
    threshold(gray,binary,0,255,THRESH_BINARY|THRESH_OTSU);

//  形态学与距离变换
    Mat Kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));
    morphologyEx(binary,binary,MORPH_OPEN,Kernel,Point(-1,-1));
    Mat dist;
    distanceTransform(binary,dist,DistanceTypes::DIST_L2,3,CV_32F);
    normalize(dist,dist,0,1,NORM_MINMAX);

//  开始生成标记
    threshold(dist,dist,0.1,1,THRESH_BINARY);
    normalize(dist,dist,0,255,NORM_MINMAX);
    dist.convertTo(dist,CV_8UC1);

//  标记开始
    vector<vector<Point>> contours;
    vector<Vec4i> hierachy;
    findContours(dist,contours,hierachy,RETR_CCOMP,CHAIN_APPROX_SIMPLE);
    if(contours.empty()){
        return Mat();
    }
    Mat markers(dist.size(),CV_32S);
    markers = Scalar::all(0);
    for(int t=0; t< contours.size(); t++)
    {
        drawContours(markers,contours,t,Scalar(t+1),-1,8,hierachy,INT_MAX);
    }
    circle(markers,Point(5,5),3,Scalar(255),-1);

//  分水岭变换
    watershed(image,markers);
    Num_Comp = contours.size();
    return markers;
}
void Create_Display_Segments(Mat& markers, int numSegment)  //生成随机分割显示颜色
{
//  产生随机颜色
    vector<Vec3b>colors;
    for(size_t t=0; t < numSegment; t++)
    {
        int r = theRNG().uniform(0,255);
        int g = theRNG().uniform(0,255);
        int b = theRNG().uniform(0,255);
        colors.push_back(Vec3b((uchar)b,(uchar)g,(uchar)r));
    }
//  颜色填充与最终显示
    Mat dst = Mat::zeros(markers.size(),CV_8UC3);
    int index = 0;
    for(int row = 0; row < markers.rows; row++) {
        for(int col = 0; col < markers.cols; col++) {
            index = markers.at<int>(row,col);
            if(index > 0 && index <= numSegment){
                dst.at<Vec3b>(row,col) = colors[index - 1];
            }else {
                dst.at<Vec3b>(row,col) = Vec3b(255,255,255);
            }
        }
    }
    imshow("final Image",dst);
    return;
}