//GMM（高斯混合模型）方法的期望最大化（E-M）
/*方法概述：
 *    高斯分布与概率密度分布 - PDF
 *    1. 根据先验概率密度和数据点的均值，对数据进行一个预分类，
 *    2. 计算每一个点分类的概率密度，计算分类最大的概率密度为后验概率密度
 *    3. 每一个数据点可能性最大的概率归到相同编号，整个能量分布最大（期望最大化）
 *样本数据训练与预言步骤：
 *    1. 随机生成像素数
 *    2. 初始化EM模型
 *    3. 利用EM模型对图像的每一个像素进行预测分类
 *    4. 画出分类点
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using  namespace cv::ml;
using namespace std;

int main(int argc, char** argv) {
    Mat img(500,500,CV_8UC3);
    RNG rng(12345);
    Scalar colorTab[] = {
            Scalar(0,0,255),
            Scalar(0,255,0),
            Scalar(255,0,0),
            Scalar(0,255,255),
            Scalar(255,0,255),
    };

//  数据初始化
    int numCluster = rng.uniform(2,5);        //分为几类
    int sampleCount = rng.uniform(5,1000);    //样本数据
    Mat point(sampleCount,2,CV_32FC1);       //随机生成点
    Mat labesl;
    Mat centers;

//  生成随机数
    for(int k = 0; k < numCluster; k++){
        Point center;
        center.x = rng.uniform(0,img.cols);
        center.y = rng.uniform(0,img.rows);
        //数据块
        Mat pointChunk = point.rowRange(k*sampleCount/numCluster, k == numCluster-1?sampleCount:(k+1)*sampleCount/numCluster);
        //随机数填充
        rng.fill(pointChunk,RNG::NORMAL,Scalar(center.x,center.y),Scalar(img.cols*0.05,img.rows*0.05));
    }
    randShuffle(point,1,&rng);

//  初始化 E M 模型
    Ptr<EM> em_model = EM::create();
    em_model->setClustersNumber(numCluster);
    em_model->setCovarianceMatrixType(EM::COV_MAT_SPHERICAL);
    em_model->setTermCriteria(TermCriteria(TermCriteria::EPS + TermCriteria::COUNT,100,0.1));
    em_model->trainEM(point,noArray(),labesl,noArray());
//  分类每个图像的像素
    Mat sample(1,2,CV_32FC1);
    for(int row=0; row<img.rows; row++){
        for(int col=0; col<img.cols; col++) {
            sample.at<float>(0) = (float)col;
            sample.at<float>(1) = (float)row;
            //GMM模型预言像素点的分类
            int respone = cvRound(em_model->predict2(sample,noArray())[1]);
            Scalar c = colorTab[respone];
            circle(img,Point(col,row),1,0.75*c,-1,8,0);
        }
    }
//  画出分类点
    for(int i=0;i<sampleCount;i++)
    {
        Point p(cvRound(point.at<float>(i,0)),cvRound(point.at<float>(i,1)));
        circle(img,p,1,colorTab[i],1,8,0);
    }
    imshow("img",img);
    waitKey(0);
    return 0;
}