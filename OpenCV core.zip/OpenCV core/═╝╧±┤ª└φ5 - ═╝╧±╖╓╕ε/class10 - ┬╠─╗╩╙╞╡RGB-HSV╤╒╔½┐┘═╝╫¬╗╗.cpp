//绿幕背景抠图
/*算法选择：
 *  1. GMM或K-Means  2.基于色彩的处理方法 3. RGB与HSV色彩
 *步骤：
 *  1. 帧图像 2.转为HSV 3.生成模型Mask 4.背景融合替换 5. 显示帧图像
 */
#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using  namespace cv::ml;
using namespace std;


Mat replace_and_blend(Mat& frame,Mat& mask,Mat& backgroud);
int main(int argc, char** argv) {
    Mat backgroud = imread("D:\\OpenCV core\\class1\\1.png");
    if (backgroud.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    imshow("src",backgroud);
    VideoCapture capture;
    capture.open("D:\\OpenCV core\\class1\\01.mp4");
    if (!capture.isOpened()) {
        printf("could not load VideoCapture...\n");
        return -1;
    }
    Mat frame,hsv,mask;
    while(capture.read(frame)){
        frame = imread("D:\\OpenCV core\\class1\\mxx.jpg");
        cvtColor(frame,hsv,CV_BGR2HSV);
        inRange(hsv,Scalar(35,43,46),Scalar(155,255,255),mask);
//      形态学操作
        Mat kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));
        morphologyEx(mask,mask,MORPH_CLOSE,kernel);
        erode(mask,mask,kernel);
        GaussianBlur(mask,mask,Size(3,3),0,0);
        Mat back1 = Mat::zeros(frame.size(),frame.type());
        Mat result = replace_and_blend(frame,mask,back1);

        char c = waitKey(1);
        if(c == 27){
            break;
        }
        imshow("result",result);
        imshow("frame",frame);
    }
    waitKey(0);
    return 0;
}
Mat replace_and_blend(Mat& frame,Mat& mask,Mat& backgroud)
{
    Mat result = Mat::zeros(frame.size(),frame.type());
    int h = frame.rows;
    int w = frame.cols;

//  替换和融合
    int m = 0;
    double wt = 0;

    int r = 0,g = 0,b = 0;
    int r1 = 0,g1 = 0,b1 = 0;
    int r2 = 0,g2 = 0,b2 = 0;

    for(int row = 0;row < h; row++){
        uchar* current =frame.ptr<uchar>(row);
        uchar* bgrow = backgroud.ptr<uchar>(row);
        uchar* maskrow = mask.ptr<uchar>(row);
        uchar* targetrow = result.ptr<uchar>(row);
        for(int col = 0; col < w; col++){
            m = *maskrow++;
            if(m == 255){  //背景
                *targetrow++ = *bgrow++;
                *targetrow++ = *bgrow++;
                *targetrow++ = *bgrow++;
                current += 3;
            }else if(m == 0){   //前景
                *targetrow++ = *current++;
                *targetrow++ = *current++;
                *targetrow++ = *current++;
                bgrow += 3;
            } else{
                b1 = *bgrow++;
                g1 = *bgrow++;
                r1 = *bgrow++;

                b2 = *current++;
                g2 = *current++;
                r2 = *current++;

                //混合权重
                wt = m / 255.0;
                b = wt * b1 + (1 - wt)* b2;
                g = wt * g1 + (1 - wt)* g2;
                r = wt * r1 + (1 - wt)* r2;

                *targetrow++ = b;
                *targetrow++ = g;
                *targetrow++ = r;
            }
        }
    }
    return result;
}