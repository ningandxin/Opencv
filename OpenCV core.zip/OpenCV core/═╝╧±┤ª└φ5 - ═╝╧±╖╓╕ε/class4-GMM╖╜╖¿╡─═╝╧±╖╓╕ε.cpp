//GMM（高斯混合模型）方法的期望最大化（E-M）
/*图像分割步骤：
 *  1. 数据初始化
 *  2. 图像RGB数据转化为样本数据
 *  3. EM模型分类训练
 *  4. EM模型进行预测
 *  4. 对每个像素标记颜色显示
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using  namespace cv::ml;
using namespace std;

int main(int argc, char** argv) {
    Mat src = imread("D:\\OpenCV core\\class1\\tx.png");
    if(src.empty()) {
        printf("the image is empty");
        return -1;
    }
    namedWindow("src",WINDOW_AUTOSIZE);
    imshow("src",src);
//  数据初始化
    int width = src.cols;
    int height = src.rows;
    int dims = src.channels();
    int sampleCount = width * height;
    int ClustersNumber = 4;
    const Scalar color[]={
            Scalar(255,0,0),
            Scalar(0,255,0),
            Scalar(0,0,255),
            Scalar(0,255,255),
    };
    Mat points(sampleCount,dims,CV_64FC1);
    Mat labels;
    Mat result = Mat::zeros(src.size(),CV_8UC3);

//  图像RGB数据转化为样本数据
    int index = 0;
    for(int row = 0; row< height; row++) {
        for(int col=0; col<width; col++){
            index = row * width + col;
            Vec3b RGB = src.at<Vec3b>(row,col);
            points.at<double>(index,0) = static_cast<int>(RGB[0]);
            points.at<double>(index,1) = static_cast<int>(RGB[1]);
            points.at<double>(index,2) = static_cast<int>(RGB[2]);
        }
    }
//  EM模型分类训练
    Ptr <EM> em_model = EM::create();
    em_model->setClustersNumber(ClustersNumber);
    em_model->setCovarianceMatrixType(EM::COV_MAT_SPHERICAL);
    em_model->setTermCriteria(TermCriteria(TermCriteria::EPS + TermCriteria::COUNT,100,0.1));
    em_model->trainEM(points,noArray(),labels,noArray());

//  对每个像素标记颜色与显示
    Mat sample(dims,1,CV_64FC1);
    int time = getTickCount();
    int r = 0,g = 0,b = 0;
    for(int row=0; row<height; row++){
        for(int col=0; col < width; col++){
            index = row * width + col;
            b = src.at<Vec3b>(row,col)[0];
            g = src.at<Vec3b>(row,col)[1];
            r = src.at<Vec3b>(row,col)[2];
            sample.at<double>(0) = static_cast<double>(b);
            sample.at<double>(1) = static_cast<double>(g);
            sample.at<double>(2) = static_cast<double>(r);
            int respose = cvRound(em_model->predict2(sample, noArray())[1]);
            Scalar c = color[respose];
            result.at<Vec3b>(row,col)[0] = c[0];
            result.at<Vec3b>(row,col)[1] = c[1];
            result.at<Vec3b>(row,col)[2] = c[2];
        }
    }
    printf("time : %d\n",(getTickCount()-time)/getTickFrequency()*1000);
    imshow("result",result);
    waitKey(0);
    return 0;
}