//分水岭分割方法
/* 1. 基于浸泡理论的分水岭分割法
 * 2. 基于连通图的方法
 * 3. 基于距离变换的方法
 * 解决问题：分割粘连对象，实现形态学操作与对象计数
 * 步骤：
 * 1. 输入图像 2. 灰度化 3. 二值化 4.距离变换 5.寻找种子 6.生成Marker
 * 7. 分水岭变换 8.输出图像
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace cv::ml;
using namespace std;

int main(int argc, char** argv) {
    Mat src = imread("D:\\OpenCV core\\class1\\pill_002.png");
    if(src.empty()) {
        printf("the image is empty");
        return -1;
    }
    namedWindow("src",WINDOW_AUTOSIZE);
    imshow("src",src);

//  金字塔中值变换滤波（边缘保留滤波）
    Mat src_gray,shifted;
    pyrMeanShiftFiltering(src,shifted,21,51);

//  灰度化
    cvtColor(shifted,src_gray,CV_BGR2GRAY);

//  二值化
    Mat binaryImg;
    threshold(src_gray,binaryImg,0,255,THRESH_BINARY|THRESH_OTSU);

//  距离变换
    Mat dist;
    distanceTransform(binaryImg,dist,DistanceTypes::DIST_L2,3,CV_32F);
    normalize(dist,dist,0,1,NORM_MINMAX);

//  二值化
    threshold(dist,dist,0.4,1,THRESH_BINARY);

//  Markers
    Mat dist_m;
    vector<vector<Point>> contours;
    dist.convertTo(dist_m,CV_8U);
    findContours(dist_m,contours,RETR_EXTERNAL,CHAIN_APPROX_SIMPLE,Point(0,0));

//  create markers
    Mat markers = Mat::zeros(src.size(),CV_32SC1);
    for(size_t t=0; t< contours.size(); t++){
        drawContours(markers,contours, static_cast<int>(t),Scalar::all(static_cast<int>(t)+1),-1);
    }
    circle(markers,Point(5,5),3,Scalar(255),-1);

//  形态学操作 - 彩色图像， 目的：去掉干扰，结果更好
    Mat kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));
    morphologyEx(src,src,MORPH_ERODE,kernel);
    imshow("src Img",src);

//  完成分水岭变换
    watershed(src,markers);
    Mat mark = Mat::zeros(markers.size(),CV_8UC1);
    markers.convertTo(mark,CV_8UC1);
    bitwise_not(mark,mark,Mat());
    imshow("mark",mark);

//  产生随机颜色
    vector<Vec3b>colors;
    for(size_t t=0; t<contours.size(); t++)
    {
        int r = theRNG().uniform(0,255);
        int g = theRNG().uniform(0,255);
        int b = theRNG().uniform(0,255);
        colors.push_back(Vec3b((uchar)b,(uchar)g,(uchar)r));
    }
//  颜色填充与最终显示
    Mat dst = Mat::zeros(markers.size(),CV_8UC3);
    int index = 0;
    for(int row = 0; row < markers.rows; row++) {
        for(int col = 0; col < markers.cols; col++) {
            index = markers.at<int>(row,col);
            if(index > 0 && index <= contours.size()){
                dst.at<Vec3b>(row,col) = colors[index - 1];
            }else {
                dst.at<Vec3b>(row,col) = Vec3b(0,0,0);
            }
        }
    }
    imshow("dst",dst);
    cout << contours.size() <<endl;
    waitKey(0);
    return 0;
}