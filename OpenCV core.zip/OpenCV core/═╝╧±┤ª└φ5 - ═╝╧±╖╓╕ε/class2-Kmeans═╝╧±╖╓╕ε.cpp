//Kmeans方法 - 图像分割
/*步骤：
 *  1. 初始化一些图像像素
 *  2. RGB数据转化为一些样本数据
 *  3. 运行K-means算法，进行数据聚类
 *  4. 显示图像分割结果
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

int main(int argc, char** argv) {
    Mat src = imread("D:\\OpenCV core\\class1\\cvtest.png");
    if(!src.data) {
        printf("the image is empty\n");
        return -1;
    }
    namedWindow("src",WINDOW_AUTOSIZE);
    imshow("src",src);

    int width = src.cols;
    int height = src.rows;
    int dims = src.channels();
    Scalar colorTab[] = {
            Scalar(0, 0, 255),
            Scalar(0, 255, 0),
            Scalar(255, 0, 0),
            Scalar(0, 255, 255),
            Scalar(255, 0, 255)
    };
//   初始化定义
    int sampleCount = width * height;     //样本数目
    int clusterCount = 4;
    Mat points(sampleCount,dims,CV_32F,Scalar(10));
    Mat labels;
    Mat center(clusterCount,1,points.type());

//  RGB数据转换为样本数据
    int index = 0;
    for(int row=0; row<height; row++) {
        for(int col=0; col<width; col++) {
            index = row * width + col;      //转化为一行后的坐标位置
            Vec3b bgr = src.at<Vec3b>(row,col); //图像的每一个点的位置的rgb数据
            points.at<float>(index,0) = static_cast<int>(bgr[0]);
            points.at<float>(index,1) = static_cast<int>(bgr[1]);
            points.at<float>(index,2) = static_cast<int>(bgr[2]);
        }
    }
//  运行K-means
    TermCriteria criteria = TermCriteria(TermCriteria::EPS + TermCriteria::COUNT,10,0.1);
    kmeans(points,clusterCount,labels,criteria,3,KMEANS_PP_CENTERS,center);

//  显示图像分割结果
    Mat result = Mat :: zeros(src.size(),src.type());
    for(int row=0; row<height; row++) {
        for(int col=0; col<width; col++) {
            index = row * width + col;
            int label = labels.at<int>(index,0);
            result.at<Vec3b>(row,col)[0] = colorTab[label][0];
            result.at<Vec3b>(row,col)[1] = colorTab[label][1];
            result.at<Vec3b>(row,col)[2] = colorTab[label][2];
        }
    }

    for (int i = 0; i < center.rows; i++) {
        int x = center.at<float>(i,0);
        int y = center.at<float>(i,1);
        printf("x: %d,y: %d\n",x,y);
    }
    imshow("result",result);

    waitKey(0);
    return 0;
}