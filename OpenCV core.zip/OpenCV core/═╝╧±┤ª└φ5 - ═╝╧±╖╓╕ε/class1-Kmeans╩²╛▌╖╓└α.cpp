//Kmeans方法-原理
/*方法概述：
 *  1. 无监督学习方法
 *  2. 分类问题，输入分类数目，初始化中心位置
 *  3. 硬分类方法，以距离度量，重新计算新的中心点位置
 *  4. 迭代分类为聚类
 */
/*图像分类过程：
 *  1. 生成随机数利用rng，随机确定中心点位置
 *  2. 利用kmeans进行数据三次分类，确定聚类标签label
 *  3. 使用不同颜色显示分类
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

int main(int argc, char** argv) {

    Mat img(500,500,CV_8UC3);
    RNG rng(12345);

    Scalar colorTab[] = {
        Scalar(0,0,255),
        Scalar(0,255,0),
        Scalar(255,0,0),
        Scalar(0,255,255),
        Scalar(255,0,255),
    };
    int numCluster = rng.uniform(2,5);  //分为几类
    cout << numCluster<<endl;

    int sampleCount = rng.uniform(5,1000);
    Mat point(sampleCount,1,CV_32FC2);  //随机生成点
    Mat labesl;
    Mat centers;

//    生成随机数
    for(int k = 0; k < numCluster; k++){
        Point center;
        center.x = rng.uniform(0,img.cols);
        center.y = rng.uniform(0,img.rows);
//    数据块
        Mat pointChunk = point.rowRange(k*sampleCount/numCluster, k == numCluster-1?sampleCount:(k+1)*sampleCount/numCluster);
        rng.fill(pointChunk,RNG::NORMAL,Scalar(center.x,center.y),Scalar(img.cols*0.05,img.rows*0.05)); //填充
    }
    randShuffle(point,1,&rng);

//    使用KMeans
    kmeans(point,numCluster,labesl,TermCriteria(TermCriteria::EPS + TermCriteria::COUNT,10,0.1),3,
           KMEANS_PP_CENTERS,centers);
//    用不同颜色显示分类
    img = Scalar::all(255);
    for(int i=0 ;i<sampleCount; i++ )       //多少个点
    {
        int index = labesl.at<int>(i);      //labels 是聚类编号
        Point p = point.at<Point2f>(i);
        circle(img,p,2,colorTab[index],-1,8,0);
    }
//    每个聚类的中心画圆
    for(int i=0;i<centers.rows;i++)
    {
        int x = centers.at<float>(i,0);
        int y = centers.at<float>(i,1);
        circle(img,Point(x,y),40,colorTab[i],1,LINE_AA);
    }
    imshow("KMeans - data",img);
    waitKey(0);
    return 0;
}