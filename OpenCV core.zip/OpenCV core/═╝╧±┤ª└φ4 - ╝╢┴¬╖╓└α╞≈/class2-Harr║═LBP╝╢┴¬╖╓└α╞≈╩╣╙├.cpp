// Haar与LBP级联分类器使用：
/* opencv中的Haar与LBP数据
 * Harr与LBP区别:
    1. Harr特征是浮点数计算
    2. LBP特征是整数计算
    3. LBP训练需要的样本数量要比HARR大
    4. 同样的样本空间，Harr训练出来的数据检测结果比LBP准确
    5. 扩大LBP的样本数据，训练结果可以和Haar一样
    6. LBP的速度一般比Harr快几倍
 */
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

String harrFilePath = "G:\\opencv\\build\\etc\\haarcascades\\haarcascade_frontalface_alt.xml";
String lbpFilePath = "G:\\opencv\\build\\etc\\lbpcascades\\lbpcascade_frontalface.xml";
CascadeClassifier harrface_class;
CascadeClassifier lbpface_class;

int main(int argc, char** argv) {

    Mat src_gray,dst;
    if(!harrface_class.load(harrFilePath))   //load cascade
    {
        printf("could not load face image");
        return -1;
    }
    if(!lbpface_class.load(lbpFilePath))   //load cascade
    {
        printf("could not load eye image");
        return -1;
    }
//    open video
    VideoCapture capture(0);
    Mat frame;
    vector<Rect> face;
//    capture.open("");
    while(capture.read(frame))
    {
       cvtColor(frame,src_gray,CV_BGR2GRAY);
       equalizeHist(src_gray,src_gray);
        lbpface_class.detectMultiScale(src_gray,face);
       for(size_t t=0; t< face.size(); t++)
       {
           rectangle(frame,face[t],Scalar(255,0,0),2,8,0);
       }
       imshow("demo-win",frame);
        char c = waitKey(20);
        if(c == 27) {
            break;
        }
    }
//    视频释放
    capture.release();
/*
//  open image
    Mat src = imread("D:\\OpenCV core\\class1\\2.png");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);
    cvtColor(src,src_gray,CV_BGR2GRAY);
    equalizeHist(src_gray,src_gray);
//    face detect
    int  st = getTickCount();
    vector<Rect> face;
    harrface_class.detectMultiScale(src_gray,face,1.2,3,0,Size(30,30));
    int et = (getTickCount() - st);
    cout <<et <<endl;
    for(size_t t=0; t<face.size(); t++)
    {
        rectangle(src,face[static_cast<int>(t)],Scalar(0,0,255),2,8,0);
    }
    imshow("src",src);
*/
    waitKey(0);
    return 0;
}
