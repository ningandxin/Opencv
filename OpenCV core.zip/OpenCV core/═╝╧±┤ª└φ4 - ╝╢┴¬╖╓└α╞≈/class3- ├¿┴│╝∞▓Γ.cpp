// 猫脸检测
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

String harrFilePath = "G:\\opencv\\build\\etc\\haarcascades\\haarcascade_frontalcatface.xml";
String lbpFilePath = "G:\\opencv\\build\\etc\\lbpcascades\\lbpcascade_frontalcatface.xml";
CascadeClassifier harrface_class;
CascadeClassifier lbpface_class;

int main(int argc, char** argv) {

    Mat src_gray,dst;
    if(!harrface_class.load(harrFilePath))   //load cascade
    {
        printf("could not load face image");
        return -1;
    }
    if(!lbpface_class.load(lbpFilePath))   //load cascade
    {
        printf("could not load eye image");
        return -1;
    }

//  open image
    Mat src = imread("D:\\OpenCV core\\class1\\5.png");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);
    cvtColor(src,src_gray,CV_BGR2GRAY);
    equalizeHist(src_gray,src_gray);
//    face detect
    int  st = getTickCount();
    vector<Rect> face;
    harrface_class.detectMultiScale(src_gray,face,1.1,3,0,Size(10,10));
    int et = (getTickCount() - st);
    cout <<et <<endl;
    for(size_t t=0; t<face.size(); t++)
    {
        rectangle(src,face[static_cast<int>(t)],Scalar(0,0,255),2,8,0);
    }
    imshow("src",src);

    waitKey(0);
    return 0;
}
