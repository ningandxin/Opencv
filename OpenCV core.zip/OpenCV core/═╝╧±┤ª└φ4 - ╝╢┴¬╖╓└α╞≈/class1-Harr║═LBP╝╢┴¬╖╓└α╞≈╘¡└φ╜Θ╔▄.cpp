// Harr与LBP级联分类器原理介绍：
/*  Harr特征与LBP特征
    级联分类器原理 - AdaBoost
    弱分类器 - weak classifier = Ferture
    强分类器 - 多个弱分类器的线性组合
    级联分类器 - 多个强分类器组合
 */
#include <iostream>
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;

String cascadeFilePath = "G:\\opencv\\build\\etc\\haarcascades\\haarcascade_frontalface_alt.xml";
String eyeFilePath = "G:\\opencv\\build\\etc\\haarcascades\\haarcascade_eye.xml";
CascadeClassifier face_class;
CascadeClassifier eye_class;

int main(int argc, char** argv) {

    Mat src_gray,dst;
    if(!face_class.load(cascadeFilePath))   //load cascade
    {
        printf("could not load face image");
        return -1;
    }
    if(!eye_class.load(eyeFilePath))   //load cascade
    {
        printf("could not load eye image");
        return -1;
    }
///*//    open camera
    namedWindow("camera-demo",CV_WINDOW_AUTOSIZE);
    VideoCapture capture(0);
    Mat frame;
    vector<Rect> faces;
    vector<Rect> eye;
    while (capture.read(frame))
    {
        cvtColor(frame,src_gray,CV_BGR2GRAY);
        equalizeHist(src_gray,src_gray);
        face_class.detectMultiScale(src_gray,faces,1.2,3,0,Size(30,30));
        for(size_t t=0; t< faces.size(); t++)
        {
            Rect roi;
            roi.x = faces[static_cast<int>(t)].x;
            roi.y = faces[static_cast<int>(t)].y;
            roi.width = faces[static_cast<int>(t)].width;
            roi.height = faces[static_cast<int>(t)].height / 2;
            Mat face_ROI = frame(roi);
            eye_class.detectMultiScale(face_ROI,eye,1.2,3,0,Size(10,10));
            for(size_t k=0;k<eye.size();k++)
            {
                Rect rect;
                rect.x = faces[static_cast<int>(t)].x + eye[k].x;
                rect.y = faces[static_cast<int>(t)].y + eye[k].y;
                rect.width = eye[k].width;
                rect.height = eye[k].height;
                rectangle(frame,rect,Scalar(0,255,0),2,8,0);
            }
            rectangle(frame,faces[static_cast<int>(t)],Scalar(0,0,255),2,8,0);
        }
        char c = waitKey(30);
        imshow("camera-demo",frame);
        if(c == 27){
            break;
        }
    }
//*/
/*
//  open image
    Mat src = imread("D:\\OpenCV core\\class1\\2.png");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);
    cvtColor(src,src_gray,CV_BGR2GRAY);
    equalizeHist(src_gray,src_gray);
//    face detect
    vector<Rect> face;
    face_class.detectMultiScale(src_gray,face,1.1,1,0,Size(10,10));
    for(size_t t=0; t<face.size(); t++)
    {
        rectangle(src,face[static_cast<int>(t)],Scalar(0,0,255),2,8,0);
    }
    imshow("src",src);
*/
    waitKey(0);
    return 0;
}
