/*级联分类器的训练
   基本流程：
        1. 收集样本数据 - 包括正负样本 （统一尺寸、背景问题需事先处理）
        2. 数据规范化 - 大小、格式
        3. 生成vec文件与负样本列表文本文件
        4. 使用OpenCV自动的级联分类器训练工具，训练样本数据
        5. 得到最终的级联分类器数据（XML格式）
   参数详解：

   工具使用:
        G:\opencv\build\x64\vc14\bin\opencv_train\opencv_createsamples
        G:\opencv\build\x64\vc14\bin\opencv_train\opencv_traincascade
   常见错误：
 *
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

String facefile = "D:\\cascadetrain\\harrresult\\cascade.xml";
CascadeClassifier face_detector;

int main(int argc, char** argv) {

    if(!face_detector.load(facefile))
    {
        printf("the file is empty");
        return -1;
    }
    Mat frame;
    Mat src_gray,dst;
    VideoCapture capture(0);
    while(capture.read(frame))
    {
        cvtColor(frame,src_gray,CV_BGR2GRAY);
        equalizeHist(src_gray,src_gray);
        vector<Rect> faces;
        face_detector.detectMultiScale(src_gray,faces,1.4,10,0,Size(50,50));
        for(size_t t=0; t< faces.size() ;t++)
        {
            rectangle(frame,faces[t],Scalar(0,0,255),2,8,0);
        }
        imshow("src",frame);

        char c = waitKey(30);
        if(c == 27) {
            break;
        }
    }
//    Mat src = imread("D:\\OpenCV core\\class1\\1.png");

    waitKey(0);
    return 0;
}