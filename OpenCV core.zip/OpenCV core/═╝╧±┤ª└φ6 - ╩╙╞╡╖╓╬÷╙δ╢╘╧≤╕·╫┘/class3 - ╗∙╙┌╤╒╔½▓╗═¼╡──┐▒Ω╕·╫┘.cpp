//对象检测与跟踪（基于颜色）
/*  1. 利用颜色范围进行过滤
 *  2. 标注与测量
 *步骤：
 *  1. inRange过滤
 *  2. 形态学操作提取
 *  3. 轮廓查找
 *  4. 外接矩形获取
 *  5. 位置标定
 */
#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

Rect roi;
void Process_Frame(Mat& binary,Rect& rect);

int main(int argc, char** argv) {
   VideoCapture captrue;
   captrue.open("D:\\OpenCV core\\class1\\video_006.mp4");
   if(!captrue.isOpened()){
       printf("could not load video \n");
       return -1;
   }
   //形态学操作
    Mat frame,mask;
    Mat kernel1 = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));
    Mat kernel2 = getStructuringElement(MORPH_RECT,Size(5,5),Point(-1,-1));
   //显示每一帧并保存
   while (captrue.read(frame)) {
       imshow("frame",frame);
       inRange(frame,Scalar(0,127,0),Scalar(120,255,120),mask); //过滤
       morphologyEx(mask,mask,MORPH_OPEN,kernel1,Point(-1,-1),1,BORDER_CONSTANT); //开操作
       dilate(mask,mask,kernel2,Point(-1,-1),4); //膨胀
       Process_Frame(mask,roi); //轮廓发现与位置标定
       //绘制轮廓
       circle(frame,Point(roi.x+roi.width/2,roi.y+roi.height/2),roi.height/2,Scalar(0,0,255),3,8,0);
       imshow("mask",frame);

       char c = waitKey(50);
       if(c == 27){
           break;
       }
   }
   captrue.release();
   waitKey(0);
   return 0;
}
void Process_Frame(Mat& binary,Rect& rect){
//  查找轮廓
    Mat dst;
    vector<vector<Point>>contours;
    vector<Vec4i>hierachy;
    findContours(binary,contours,hierachy,RETR_EXTERNAL,CHAIN_APPROX_SIMPLE,Point(0,0));
    if(contours.size()>0){
        double maxArea = 0.0;
        for(size_t t=0; t<contours.size(); t++){
            double area = contourArea(contours[t]); //轮廓区域
            if(area > maxArea){
                maxArea = area;
                rect = boundingRect(contours[t]);   //外接矩形
            }
        }
    } else{
        rect.x =  rect.y = rect.height = rect.width = 0;
    }

}