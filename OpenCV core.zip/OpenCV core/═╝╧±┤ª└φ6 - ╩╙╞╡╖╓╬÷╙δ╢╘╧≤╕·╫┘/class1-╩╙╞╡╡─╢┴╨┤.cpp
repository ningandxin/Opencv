//视频读写：典型支持为-avi与mp4
//视频类： VideoCapture read isOpened release
/*视频格式与相关API介绍
 *从视频文件中读写视频
 *从摄像头中读写视频
 *    写视频的编码格式：
 *    fourcc.org
 *    -CV_FOURCC('D','I','V','X') = MPEG-4 codec
 *    -CV_FOURCC('P','I','M','1') = MPEG-1 codec
 *    -CV_FOURCC('U','2','6','3') = H263 codec
 */
#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

int main(int argc, char** argv) {
   VideoCapture captrue(0);
//   captrue.open("D:\\OpenCV core\\class1\\vtest.avi");
   if(!captrue.isOpened()){
       printf("could not load video \n");
       return -1;
   }
   //视频参数初始化
   double fps = captrue.get(CV_CAP_PROP_FPS); //获取帧数
   Size size = Size(captrue.get(CV_CAP_PROP_FRAME_WIDTH),captrue.get(CV_CAP_PROP_FRAME_HEIGHT)); //获取图像大小
   cout <<fps<<endl;
   VideoWriter writer("D:\\OpenCV core\\1.avi",CV_FOURCC('D','I','V','X'),15,size, true); //保存视频
   Mat frame,gray,binary;

   //显示每一帧并保存
   while (captrue.read(frame)) {
//       cvtColor(frame,gray,CV_BGR2GRAY);
//       threshold(gray,binary,0,255,THRESH_BINARY|THRESH_OTSU);
       bitwise_not(frame,frame);
       imshow("frame",frame);
//       writer.write(frame);
       char c = waitKey(50);
       if(c == 27){
           break;
       }
   }
   captrue.release();
    waitKey(0);
    return 0;
}
