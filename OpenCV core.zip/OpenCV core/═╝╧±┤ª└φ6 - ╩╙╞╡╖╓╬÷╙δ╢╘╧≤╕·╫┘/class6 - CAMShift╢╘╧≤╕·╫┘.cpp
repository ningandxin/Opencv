//CAMShift对象跟踪
/* MeanShift算法介绍：
 *    根据每一个点的核函数与高斯权重，求出每点与中心点距离的均值，不断移动距离更换中心点。
 *    原理是求出每个点的概率密度
 * 最后迭代到中心点到密度较高的位置
 * CAMShift跟踪介绍
 *     连续自适应的MeanShift跟踪算法：
 *     -窗口尺寸自动变换
 *     -适合变形目标检测
 * 步骤：
 *  1. 选取帧数  2. 选择ROI区域  3. HSV空间H通道直方图表达
 *  4. 直方图反向映射 5. CAMShift位置跟踪 6. 绘制位置更新显示
 */
#include <opencv2/opencv.hpp>
#include <opencv2/tracking.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

int smin = 20;
int vmin = 40;
int bins = 16;
int main(int argc, char** argv) {
   VideoCapture capture;
   capture.open("D:\\OpenCV core\\class1\\video_003.avi");

   if(!capture.isOpened()){
       printf("could not load video \n");
       return -1;
   }

   bool firstRead = true;
   float hst_ranges[] = {0,180};
   Rect selection;
   const float* hranges = hst_ranges;
   Mat frame,hsv,hue,mask,hist,backproject;

   Mat drawImg = Mat::zeros(200,300,CV_8UC3);  //直方图
   for(int i=0;i<15;i++){
       capture.read(frame);
   }
   while (capture.read(frame))
   {
       if(firstRead){
           Rect2d first = selectROI("src", frame);
           selection.x = first.x;
           selection.y = first.y;
           selection.width = first.width;
           selection.height = first.height;
           printf("ROI.x = %d,Roi.y = %d,width= %d, height = %d\n",
                  selection.x,selection.y,selection.width,selection.height);
       }
//     convert to HSV
       cvtColor(frame,hsv,CV_BGR2HSV);
       inRange(hsv,Scalar(0,smin,vmin),Scalar(180,256,256),mask);
       hue = Mat(hsv.size(),hsv.depth());
       int channels[]={0,0};
       mixChannels(&hsv,1,&hue,1,channels,1);

        if(firstRead)
        {
            // calculate histogram
            Mat roi(hue,selection);
            Mat maskroi(mask,selection);
            calcHist(&roi,1,0,maskroi,hist,1,&bins,&hranges);  //计算直方图
            normalize(hist,hist,0,255,NORM_MINMAX);

            //show histogram
            int binw = drawImg.cols / bins;      //直方图宽度
            Mat colorIndex = Mat(1,bins,CV_8UC3);
            for(int i=0; i< bins;i++){   //定义直方图不同颜色
                colorIndex.at<Vec3b>(0,i) = Vec3b(static_cast<uchar>(i*180/bins),255,255);
            }
            cvtColor(colorIndex,colorIndex,CV_HSV2BGR);
            for(int i=0; i<bins;i++){   //直方图显示
                int value = static_cast<int>(hist.at<float>(i)*drawImg.rows / 255);  //直方图高度
                rectangle(drawImg,Point(i*binw,drawImg.rows),Point((i+1)*binw,drawImg.rows - value),
                          colorIndex.at<Vec3b>(0,i),-1,8,0);
            }
            firstRead = false;
        }
//     back projection
       calcBackProject(&hue,1,0,hist,backproject,&hranges,1, true);

//     CAMShift tracking
       backproject &= mask;
       RotatedRect trackBox = CamShift(backproject,selection,TermCriteria((TermCriteria::COUNT
                                                                           |TermCriteria::EPS),10,1));
//     draw location on frame
       ellipse(frame,trackBox,Scalar(0,0,255),2,8);

       imshow("backproject",backproject);
       imshow("frame",frame);
       imshow("drawImg",drawImg);

       char c = waitKey(50);
       if(c == 27){
           break;
       }
   }
   capture.release();
   waitKey(0);
   return 0;
}
