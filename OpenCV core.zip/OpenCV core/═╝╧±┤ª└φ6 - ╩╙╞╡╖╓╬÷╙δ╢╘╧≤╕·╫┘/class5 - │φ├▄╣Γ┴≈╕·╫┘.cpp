//稠密光流 - HF
#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;
void drawOpticalFlowHF(const Mat& flowdata , Mat&image, int step);
int main(int argc, char** argv) {
   VideoCapture captrue;
   captrue.open("D:\\OpenCV core\\class1\\video_003.avi");
   if(!captrue.isOpened()){
       printf("could not load video \n");
       return -1;
   }

    Mat frame,mask,gray;
    Mat prev_frame,pre_gray;    //前一帧和前一帧灰度图像
    Mat flowResult,flowdata;    //光流数据
    captrue.read(frame);
    cvtColor(frame,pre_gray,CV_BGR2GRAY);
   //从第二帧数据开始读
   while (captrue.read(frame))
   {
       cvtColor(frame,gray,CV_BGR2GRAY);
       if(!pre_gray.empty()){
            calcOpticalFlowFarneback(pre_gray,gray,flowdata,0.5,3,15,3,5,1.2,0);
            cvtColor(pre_gray,flowResult,CV_GRAY2BGR);
            drawOpticalFlowHF(flowdata,flowResult,1);
            imshow("frame",frame);
            imshow("flowResult",flowResult);
            swap(pre_gray,gray);
       }
       char c = waitKey(50);
       if(c == 27){
           break;
       }
   }
   captrue.release();
   waitKey(0);
   return 0;
}
void drawOpticalFlowHF(const Mat& flowdata , Mat&image, int step)
{
    for(int row = 0; row < image.rows; row++){
        for(int col = 0; col < image.cols; col++){
            const Point2f fxy = flowdata.at<Point2f>(row,col);
            if(fxy.x > 1||fxy.y > 1){
                line(image,Point(col,row),Point(cvRound(col+fxy.x),cvRound(row+fxy.y)),Scalar(0,255,0),2,8,0);
                circle(image,Point(col,row),2,Scalar(0,0,255),-1);
            }
        }
    }
}