//背景消除建模：
/*Backgroud Subtraction基本原理
 *  1.图像分割（GMM - 高斯混合模型）
 *  2.机器学习（KNN - k个最近邻）
 */
#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

int main(int argc, char** argv) {
   VideoCapture captrue(0);
//   captrue.open("D:\\OpenCV core\\class1\\video_004.avi");
   if(!captrue.isOpened()){
       printf("could not load video \n");
       return -1;
   }
   //形态学操作
    Mat kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));


   Mat frame,bsmaskMOG2,pmaskKNN;
   Ptr<BackgroundSubtractor>pMoG2 = createBackgroundSubtractorMOG2(); //高斯混合模型背景消除
   Ptr<BackgroundSubtractor>pKNN = createBackgroundSubtractorKNN();   //K邻近值背景消除

   //显示每一帧并保存
   while (captrue.read(frame)) {
       imshow("frame",frame);
       //MOG BS
       pMoG2 -> apply(frame,bsmaskMOG2);
//       morphologyEx(bsmaskMOG2,bsmaskMOG2,MORPH_OPEN,kernel,Point(-1,-1)); //开操作
       imshow("bsmaskMOG2",bsmaskMOG2);

       //KNN BS
       pKNN -> apply(frame,pmaskKNN);
       imshow("pmaskKNN",pmaskKNN);

       char c = waitKey(50);
       if(c == 27){
           break;
       }
   }
   captrue.release();
   waitKey(0);
   return 0;
}
