//光流的对象跟踪
/* 移动对象跟踪三要素：
 *   1.图像表示 2. 移动模型  3.外观模型
 * 基本原理：
 *   假设：1.近距离移动 2. 颜色恒定 3. 空间一致性
 *   数学模型:I(x,y,t) = I(x+u,y+v,t+l)  I(x,y,t)点的检测是通过Harris 和 shi_Tomasi特征检测
 * 步骤：
 *   1. 输入第一帧图像  2. 特征点检测选择 3. 保存特征点  4.输入第二帧图像进行跟踪
 *   5. 跟踪特征点  6. 删除损失特征点 7. 保存特征点   8.用第二帧图像替换第一帧图像
 *   9. 选择新的特征点来替换损失特征点数据  10. 保存特征点数据
 */
#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;
Mat frame,mask,gray;
Mat prev_frame,pre_gray;    //前一帧和前一帧灰度图像
vector<Point2f>features ;  //shi-Tomasi角点检测-特征数据
vector<Point2f>iniPoints;  //初始化特征数据
vector<Point2f>fpts[2];    //保持当前帧和前一帧的特征点位置
vector<uchar> status;      //特征点跟踪成功标志位
vector<float> errors;      //跟踪时候区域误差和

void drawFeature(Mat& inFrame);
void detectFeature(Mat& InFrame, Mat& ingray);
void KLTrackFeature();
void drawTrackLine();
int main(int argc, char** argv) {
   VideoCapture captrue(0);
//   captrue.open("D:\\OpenCV core\\class1\\video_003.avi");
   if(!captrue.isOpened()){
       printf("could not load video \n");
       return -1;
   }
   //显示每一帧并保存
   while (captrue.read(frame))
   {
       flip(frame,frame,1);  //摄像头画面左右对换
       cvtColor(frame,gray,CV_BGR2GRAY);
       if(fpts[0].size() < 40){
           detectFeature(frame,gray);               //探测特征
           fpts[0].insert(fpts[0].end(),features.begin(),features.end());       //初始化前一帧特征
           iniPoints.insert(iniPoints.end(),features.begin(),features.end());   //初始化特征点
       } else{
           cout <<"tracking"<<endl;
           cout <<"feature: "<< fpts[0].size()<<endl;
       }

       if(pre_gray.empty()){
           gray.copyTo(pre_gray);
       }
       KLTrackFeature();        //LK光流检测
       drawFeature(frame);      //画出LK光流点

       //更新前一帧数据
       gray.copyTo(pre_gray);
       frame.copyTo(prev_frame);
       imshow("frame",frame);

       char c = waitKey(50);
       if(c == 27){
           break;
       }
   }
   captrue.release();
   waitKey(0);
   return 0;
}
void detectFeature(Mat& InFrame, Mat& ingray){      //特征点检测
    double maxCorner = 5000;
    double qualitylevel = 0.01;
    double minDistance = 10;
    double blockSize = 3;
    double k = 0.04;
    goodFeaturesToTrack(ingray,features,maxCorner,qualitylevel,minDistance,Mat(),blockSize, false,k);
}
void drawFeature(Mat& inFrame){                     //画出特征点
    for(size_t t=0;t< fpts[1].size(); t++){
        circle(inFrame,fpts[1][t],2,Scalar(0,0,255),1,8,0);
    }
}
void KLTrackFeature(){                          //LK光流检测
    calcOpticalFlowPyrLK(pre_gray,gray,fpts[0],fpts[1],status,errors);
    int k = 0;
    for(int i=0; i<fpts[1].size();i++){
        double dist = abs(fpts[0][i].x - fpts[1][i].x) + abs(fpts[0][i].y - fpts[1][i].y);
        if(dist > 2 && status[i]){
            iniPoints[k] = iniPoints[i];
            fpts[1][k++] = fpts[1][i];
        }
    }
    //保存特征点并绘制位置轨迹
    iniPoints.resize(k);
    fpts[1].resize(k);
    drawTrackLine();
    std::swap(fpts[1],fpts[0]); //交换两个容器里面的特征点，进一步跟踪
}
void drawTrackLine(){       //初始点到终点距离
    for (size_t t=0; t<fpts[1].size(); t++) {
        line(frame, iniPoints[t], fpts[1][t], Scalar(0, 255, 0), 1, 8, 0);
        circle(frame, fpts[1][t], 2, Scalar(0, 0, 255), 2, 8, 0);
    }
}