//人脸识别算法之LBPH
/*基本流程：
    输入人脸 -> 人脸数据表示 ->LBPH特征提取 ->人脸图像与特征数据库进行对比
    ->分类识别 ->识别人脸
  LBPH算法介绍：
    1. 输入图像
    2. 图像灰度化
    3. LBP特征提取
    4. ULBP降维处理
    5. 分割为多个方格
    6. 每个方格生成直方图
    7. 直方图链接，特征向量集合
    8. 与DB中直方图对比（直方图比较）
    9. 得到分类结果
*/
#include <opencv2/opencv.hpp>
#include <opencv2/face.hpp>
#include <iostream>

using namespace std;
using namespace cv::face;
using namespace cv;

int main(int argc , char* argv){
    string filename = string("E:\\AI\\orl_faces\\image.txt");
    ifstream file(filename.c_str(),ifstream::in);
    if(!file){
        printf("could not load file \n");
        return -1;
    }
    string line,path,classlabel;
    vector<Mat>images;
    vector<int> labels;
    char separator =';';
    while(getline(file,line)){
        stringstream liness(line);
        getline(liness,path,separator);
        getline(liness,classlabel);
        if(!path.empty() && !classlabel.empty()){
            images.push_back(imread(path,0));
            labels.push_back(atoi(classlabel.c_str()));
        }
    }

    if(images.size() < 1 || labels.size() < 1){
        printf("could not load file path\n");
        return -1;
    }

    int height = images[0].rows;
    int width  = images[0].cols;

    //test Samples
    Mat testSamples = images[images.size() - 1];
    int testLabel   = labels[labels.size() - 1];
    images.pop_back();
    labels.pop_back();

    //train it
    Ptr<LBPHFaceRecognizer> model = LBPHFaceRecognizer::create();
    model->train(images, labels);

    //recognition face
    int predictedLabel = model ->predict(testSamples);
    printf("actual label :%d, predict label :%d \n",testLabel,predictedLabel);

    //print parameter
    int radius = model->getRadius();
    int neibs = model->getNeighbors();
    int grad_x = model->getGridX();
    int grad_y = model->getGridX();
    double t = model-> getThreshold();

    printf("radius: %d\n",radius);
    printf("neibs: %d\n",neibs);
    printf("grad_x: %d\n",grad_x);
    printf("grad_y: %d\n",grad_y);
    printf("t: %.2f\n",t);

    waitKey(0);
    return 0;
}
