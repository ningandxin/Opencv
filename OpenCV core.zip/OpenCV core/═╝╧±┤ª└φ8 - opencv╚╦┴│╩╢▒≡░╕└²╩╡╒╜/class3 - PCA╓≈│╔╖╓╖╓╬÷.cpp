//PCA原理介绍
/*作用
    1. 通过对高维数据分析发现他们的相同与不同表达为一个低维数据模式
    2. 主成分不变
    3. 细微损失
    4. 高维数据到低维数据
步骤：
    1. 样本数据
    2. 减去均值
    3. 计算协方差矩阵
    4. 计算特征值与特征向量
    5. 根据特征值排序保留前K个主成分特征向量
    6. 形成新的数据样本
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace std;
using namespace cv;
double Clac_PCA_Orienration(vector<Point>& pts,Mat & result);
int main(int argc , char* argv){
    Mat src =  imread("E:\\AI\\OpenCV core\\class1\\pca_test1.jpg",-1);
    if(!src.data){
        printf("could not load image");
        return -1;
    }
    imshow("input image",src);
    //binary image
    Mat gray,binary;
    cvtColor(src,gray,CV_BGR2GRAY);
    threshold(gray,binary,100,200,THRESH_BINARY|THRESH_OTSU);

    // 绘制轮廓
    vector<Vec4i> hierachy;
    vector<vector<Point>> contours;
    findContours(binary,contours,hierachy,RETR_LIST,CHAIN_APPROX_NONE);
    Mat result = src.clone();
    for(int t=0; t < contours.size(); t++){
        double area = contourArea(contours[t]);
        if(area > 1e5 || area < 1e2) continue;
        drawContours(result,contours,t,Scalar(0,0,255),2,8);
        double theta = Clac_PCA_Orienration(contours[t],result);

    }
    imshow("result image",result);

    waitKey(0);
    return 0;
}
double Clac_PCA_Orienration(vector<Point>& pts,Mat & result){
    int size = static_cast<int>(pts.size());
    Mat data_pts = Mat(size,2,CV_64FC1);
    //contours x y transfer to data
    for(int i=0; i< size ; i++){
        data_pts.at<double>(i,0) = pts[i].x;
        data_pts.at<double>(i,1) = pts[i].y;
    }
    //  perform PCA projection
    PCA pca_analysis(data_pts,Mat(),CV_PCA_DATA_AS_ROW);
    Point cnt = Point(static_cast<int>(pca_analysis.mean.at<double>(0,0)),
            static_cast<int>(pca_analysis.mean.at<double>(0,1)));
    circle(result,cnt,2,Scalar(0,255,0),2,8);

    //solve eigen_value and eigen_vector
    vector<Point2d> eign_vector(2);
    vector<double> eign_value(2);
    for(int i=0; i< 2; i++){
        eign_vector[i] = Point2d(pca_analysis.eigenvectors.at<double>(i,0),
                               pca_analysis.eigenvectors.at<double>(i,1));
        eign_value[i] = pca_analysis.eigenvalues.at<double>(i,0);
        printf("th %d eigen value:%.2f\n",i,eign_value[i]);
    }

    //solve x and y offset
    Point p1 = cnt + 0.02*Point(static_cast<int>(eign_vector[0].x*eign_value[0]),
            static_cast<int>(eign_vector[0].y*eign_value[0]));
    Point p2 = cnt - 0.05*Point(static_cast<int>(eign_vector[1].x*eign_value[1]),
                           static_cast<int>(eign_vector[1].y*eign_value[1]));
    line(result,cnt,p1,Scalar(255,0,0),2,8,0);
    line(result,cnt,p2,Scalar(255,255,0),2,8,0);

    //solve offset angle
    double angle = atan2(eign_vector[0].y,eign_vector[0].x);
    cout <<180 * (angle/CV_PI) <<endl;
    return angle;
}