//特征值与特征向量
//eigen
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace std;
using namespace cv;

int main(int argc , char* argv){

    Mat data = (Mat_<double >(2,2)<< 1,2,2,1);
    Mat eigenvalue,eigenvector;
    eigen(data,eigenvalue,eigenvector);
    for(int i=0;i<eigenvalue.rows;i++){
        cout <<eigenvalue.at<double>(i) << endl;
    }
    cout <<eigenvector << endl;

    waitKey(0);
    return 0;
}