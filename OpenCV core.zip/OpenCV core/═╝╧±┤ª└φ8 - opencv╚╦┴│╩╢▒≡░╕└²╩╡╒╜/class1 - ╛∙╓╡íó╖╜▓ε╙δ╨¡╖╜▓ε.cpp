//均值、方差与协方差
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace std;
using namespace cv;

int main(int argc , char* argv){
    Mat src = imread("E:\\AI\\OpenCV core\\class1\\3.jpg");
    if(src.empty()){
        printf("could not read image");
        return -1;
    }
    imshow("src",src);

    Mat means,stddev;
    meanStdDev(src,means,stddev);  //图像的协方差与均值
    Mat sample = (Mat_<double>(5,3)<<90,60,90,90,90,30,60,60,60,60,60,90,30,30,30);
    vector <Mat> samples ;
    split(src,samples);
    Mat cov,mean;

    calcCovarMatrix(sample,cov,mean,CV_COVAR_NORMAL|CV_COVAR_ROWS);
    cout << cov<<" "<< mean <<endl;
    waitKey(0);
    return 0;
}