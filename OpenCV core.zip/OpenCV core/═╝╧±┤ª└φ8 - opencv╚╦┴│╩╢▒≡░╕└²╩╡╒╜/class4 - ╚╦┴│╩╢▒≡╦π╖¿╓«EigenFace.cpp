//人脸识别算法之EigenFace
/* 数据集
 https://www.yahoo.com
算法训练与识别：
    1. 读训练数据
    2. 计算平均脸
    3. 计算协方差矩阵
    4. 计算特征值
    5. 计算特征矩阵
    6. PCA降维
    7. 子空间模型
    8. 检测/距离
相关API Ptr<BasicFaceRecognizer> model = createEigenFaceRecognizer();
 */
#include <opencv2/opencv.hpp>
#include <opencv2/face.hpp>
#include <iostream>

using namespace std;
using namespace cv::face;
using namespace cv;

int main(int argc , char* argv){
    string filename = string("E:\\AI\\orl_faces\\image.txt");
    ifstream file(filename.c_str(),ifstream::in);
    if(!file){
        printf("could not load file \n");
        return -1;
    }
    string line,path,classlabel;
    vector<Mat>images;
    vector<int> labels;
    char separator =';';
    while(getline(file,line)){
        stringstream liness(line);
        getline(liness,path,separator);
        getline(liness,classlabel);
        if(!path.empty() && !classlabel.empty()){
            images.push_back(imread(path,0));
            labels.push_back(atoi(classlabel.c_str()));
        }
    }

    if(images.size() < 1 || labels.size() < 1){
        printf("could not load file path\n");
        return -1;
    }

    int height = images[0].rows;
    int width  = images[0].cols;

    //test Samples
    Mat testSamples = images[images.size() - 1];
    int testLabel   = labels[labels.size() - 1];
    images.pop_back();
    labels.pop_back();

    //train it
    Ptr<BasicFaceRecognizer> model = EigenFaceRecognizer::create();
    model->train(images, labels);

    //recognition face
    int predictedLabel = model ->predict(testSamples);
    printf("actual label :%d, predict label :%d \n",testLabel,predictedLabel);

    //produce mean face
    Mat eigenvalues = model->getEigenValues();
    Mat eigenvector = model->getEigenVectors();
    Mat mean = model->getMean();
    Mat meanFace = mean.reshape(1,height);
    Mat dst;
    if(meanFace.channels() == 1){
        normalize(meanFace,dst,0,255,NORM_MINMAX,CV_8UC1);
    } else{
        normalize(meanFace,dst,0,255,NORM_MINMAX,CV_8UC3);
    }
    imshow("dst",dst);

    //Show eigen face
    for(int i=0;i<min(10,eigenvector.cols);i++){

        Mat ev = eigenvector.col(i).clone();
        Mat grayscale;
        Mat eigenFace = ev.reshape(1,height);
        if(eigenFace.channels() == 1){
            normalize(meanFace,grayscale,0,255,NORM_MINMAX,CV_8UC1);
        } else{
            normalize(meanFace,grayscale,0,255,NORM_MINMAX,CV_8UC3);
        }
        Mat colorface;
        applyColorMap(grayscale,colorface,COLORMAP_BONE);
        char * winTitle = new char[128];
        sprintf(winTitle,"eigenface_%d",i);
        imshow(winTitle,colorface);
    }

    //reconstruction face
    for(int num = min(10,eigenvector.cols);num < min(160,eigenvector.cols);num+=15){
        Mat evs = Mat(eigenvector,Range::all(),Range(0,num));
        Mat projection = LDA::subspaceProject(evs,mean,images[0].reshape(1,1));
        Mat reconstruction = LDA::subspaceReconstruct(evs,mean,projection);

        Mat result = reconstruction.reshape(1, height);
        if (result.channels() == 1) {
            normalize(result, reconstruction, 0, 255, NORM_MINMAX, CV_8UC1);
        }
        else if (result.channels() == 3) {
            normalize(result, reconstruction, 0, 255, NORM_MINMAX, CV_8UC3);
        }
        char * winTitle = new char[128];
        sprintf(winTitle,"recon_face%d",num);
        imshow(winTitle,reconstruction);
    }

    waitKey(0);
    return 0;
}
