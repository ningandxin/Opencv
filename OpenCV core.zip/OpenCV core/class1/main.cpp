//视频中的移动对象统计
/*基本思路与步骤：
 *  1.基于BSM模型
 *  2.提取前景ROI区域对象轮廓
 *  3.排除干扰与统计
 */
#include <opencv2/opencv.hpp>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

int main(int argc, char** argv) {
    VideoCapture captrue;
    captrue.open("D:\\OpenCV core\\class1\\vtest.avi");
    if(!captrue.isOpened()){
        printf("could not load video \n");
        return -1;
    }

//  初始化BS模型
    Ptr<BackgroundSubtractor>pMog2 = createBackgroundSubtractorMOG2();
    Mat kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));
    Mat frame,mogMask;
    vector<vector<Point>> contours;
    vector<Vec4i>hierachy;
    int cout = 0;
    char numText[8];
    while (captrue.read(frame)) {
        imshow("input video", frame);
        pMog2->apply(frame, mogMask);
        threshold(mogMask, mogMask, 100, 255, THRESH_BINARY);
        morphologyEx(mogMask, mogMask, MORPH_OPEN, kernel, Point(-1, -1));

        findContours(mogMask, contours, hierachy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE, Point(0, 0));
        cout = 0;
        for (size_t t = 0; t < contours.size(); t++) {
            double area = contourArea(contours[t]);
            if (area < 1000) continue;
            Rect selection = boundingRect(contours[t]);
            if (selection.width < 30 || selection.height < 30) continue;
            cout++;
            rectangle(frame, selection, Scalar(0, 0, 255), 2, 8);

            sprintf(numText, "%d", cout);
            putText(frame, numText, Point(selection.x, selection.y), CV_FONT_NORMAL, FONT_HERSHEY_PLAIN, Scalar(255, 0, 0), 1, 8);
        }

        imshow("frame",frame );

        char c = waitKey(50);
        if(c == 27){
            break;
        }
    }
    captrue.release();
    waitKey(0);
    return 0;
}
