//CNN预测年龄性别
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <iostream>

using namespace cv;
using namespace cv::dnn;
using namespace std;

String harr_file = "E:\\opencv\\build\\etc\\haarcascades\\haarcascade_frontalface_alt.XML";
String age_model = "E:\\AI\\dnn_model\\AgeGenderDeepLearning-master\\models\\age_net.caffemodel";
String age_text = "E:\\AI\\dnn_model\\AgeGenderDeepLearning-master\\age_net_definitions\\deploy.prototxt";

String gender_model = "E:\\AI\\dnn_model\\AgeGenderDeepLearning-master\\models\\gender_net.caffemodel";
String gender_text = "E:\\AI\\dnn_model\\AgeGenderDeepLearning-master\\gender_net_definitions\\deploy.prototxt";

void predict_age(Net& net, Mat& image);
void predict_gender(Net& net, Mat& image);
int main(int argc, char** argv) {
    Mat result;
    Mat src = imread("E:\\AI\\OpenCV core\\class1\\1.jpg");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);

    //读取网络模型
    Net age_net = readNetFromCaffe(age_text,age_model);
    Net gender_net = readNetFromCaffe(gender_text,gender_model);

    //分类器
    CascadeClassifier detector;
    detector.load(harr_file);
    vector<Rect> face;
    Mat gray,face_image;
    cvtColor(src,gray,CV_BGR2BGRA);
    detector.detectMultiScale(gray,face,1.03,3,0,Size(60,60),Size(300,300));
    for(size_t t=0;t<face.size();t++){
        rectangle(src,face[t],Scalar(30,255,30),2,8,0);
        face_image = src(face[t]);
        predict_age(age_net,face_image);
        predict_gender(gender_net,face_image);
    }
    imshow("age-gender-prediction-demo",src);
    waitKey(0);
    return 0;
}
vector<String>age_label(){
    vector<String>ages;
    ages.push_back("0-2");
    ages.push_back("4-6");
    ages.push_back("8-13");
    ages.push_back("15-20");
    ages.push_back("25-32");
    ages.push_back("33-36");
    ages.push_back("38-43");
    ages.push_back("60-");
    return ages;
}
void predict_age(Net& net, Mat& image){
    //input
    Mat blob = blobFromImage(image,1.0,Size(227,227));
    net.setInput(blob,"data");
    //predict Classifier
    Mat prob = net.forward("prob");
    Mat probMat = prob.reshape(1,1);
    Point classNum;
    double classProb;
    vector<String>ages = age_label();
    minMaxLoc(probMat,NULL,&classProb,NULL,&classNum);
    int classidx = classNum.x;
    putText(image,format("age.%s",ages.at(classidx).c_str()),Point(2,10),FONT_HERSHEY_PLAIN,0.8,Scalar(0,255,0),1,8,0);
}
void predict_gender(Net& net, Mat& image){
    //input
    Mat blob = blobFromImage(image,1.0,Size(227,227));
    net.setInput(blob,"data");
    //predict classication
    Mat prob = net.forward("prob");
    Mat probMat = prob.reshape(1,1);
    putText(image,format("gender.%s",probMat.at<float>(0,0) > probMat.at<float>(0,1)?"Man":"Woman"),
            Point(2,20),FONT_HERSHEY_PLAIN,0.8,Scalar(0,255,0),1,8,0);
}