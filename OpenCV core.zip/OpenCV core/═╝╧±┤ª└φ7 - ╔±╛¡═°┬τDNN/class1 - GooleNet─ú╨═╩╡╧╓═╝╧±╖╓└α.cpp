//GoogleNet模型实现图像分类
/*步骤：
 * 1. 读取分类层数文件
 * 2. 从caffe读取网络模型
 * 3. 将image图像转化为blob图像
 * 4. 得到的prob矩阵转化为一行，寻找最大可能性的点和最大概率
 * 5. 显示最大值点和概率
 */

#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <iostream>

using namespace cv;
using namespace cv::dnn;
using namespace std;

String model_bin_file = "E:\\AI\\OpenCV core\\class1\\bvlc_googlenet.caffemodel";
String model_txt_file = "E:\\AI\\OpenCV core\\class1\\bvlc_googlenet.prototxt";
String label_txt_file = "E:\\AI\\OpenCV core\\class1\\synset_words.txt";
vector<String> readLabel();
int main(int argc, char** argv) {
    Mat src = imread("E:\\AI\\OpenCV core\\class1\\space_shuttle.jpg");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);

    vector<String> labels = readLabel();
    //from caffe read net
    Net net = readNetFromCaffe(model_txt_file,model_bin_file);
    if(net.empty()){
        cout <<"read caffe model data failure"<<endl;
        return -1;
    }
    //image to blob
    Mat prob;
    Mat inputBlob = blobFromImage(src,1.0,Size(224,224),Scalar(104,117,123));
    for(int i=0;i<10;i++){
        net.setInput(inputBlob,"data");
        prob = net.forward("prob");
    }
    Mat probMat = prob.reshape(1,1);
    Point classNumber;
    double classProb;
    minMaxLoc(probMat,NULL,&classProb,NULL,&classNumber);  //最大的点的数
    int classidx = classNumber.x;
    printf("current image classification:%s,possible: %.2f\n",labels.at(classidx).c_str(),classProb);
    putText(src,labels.at(classidx),Point(20,20),FONT_HERSHEY_PLAIN,1.0,Scalar(0,0,255),1,8,0);
    imshow("input image", src);

    waitKey(0);
    return 0;
}
vector<String> readLabel(){         //readfile
    vector<String> classNames;
    ifstream fb(label_txt_file);
    if(!fb.is_open()){
        cout<<"could not open the file"<<endl;
        exit(-1);
    }
    string name;
    while (!fb.eof()){
        getline(fb, name);
        if(name.length()){
            classNames.push_back(name.substr(name.find(" ") + 1));
        }
    }
    fb.close();
    return classNames;
}