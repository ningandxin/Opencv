//FCN模型进行图像分割
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <iostream>

using namespace cv;
using namespace cv::dnn;
using namespace std;

String model_bin_file = "E:\\AI\\dnn_model\\fcn8s-heavy-pascal.caffemodel";
String model_txt_file = "E:\\AI\\dnn_model\\fcn8s-heavy-pascal.prototxt";
String label_txt_file = "E:\\AI\\dnn_model\\pascal-classes.txt";
vector<Vec3b> readColor();
int main(int argc, char** argv) {
    Mat result;
    Mat src = imread("E:\\AI\\OpenCV core\\class1\\space_shuttle.jpg");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);

    vector<Vec3b>  objcolor = readColor();  //read object color
    //init net
    Net net = readNetFromCaffe(model_txt_file,model_bin_file);
    resize(src,src,Size(500,500));
    Mat blobImage = blobFromImage(src);    //image convert to blob image

    //use net
    net.setInput(blobImage,"data");         //from data to result
    Mat score = net.forward("score");

    //segmentation and display
    const int rows = score.size[2];        //result.rows
    const int cols = score.size[3];
    const int channel = score.size[1];
    Mat maxColor(rows,cols,CV_8UC1);
    Mat maxVal(rows,cols,CV_32FC1);
    for(int c=0;c<channel;c++){
        for(int row=0;row<rows;row++){
            const float *ptrScore = score.ptr<float>(0,c,row);      //color row
            uchar *ptrMaxColor = maxColor.ptr<uchar>(row);           //find max value and channel
            uchar *ptrMaxVal = maxVal.ptr<uchar>(row);
            for(int col=0;col < cols;col++){
                if(ptrScore[col] > ptrMaxVal[col]){
                    ptrMaxVal[col] = ptrScore[col];
                    ptrMaxColor[col] = (uchar) c;
                }
            }
        }
        result = Mat::zeros(rows,cols,CV_8UC3);
        for(int row=0;row<rows;row++) {
            const uchar* ptrMaxcl = maxColor.ptr<uchar>(row);       //each pixel to result
            Vec3b* ptrColor = result.ptr<Vec3b>(row);
            for(int col=0;col < cols;col++){
                ptrColor[col] = objcolor[ptrMaxcl[col]];
            }
        }
    }

    Mat dst;
    addWeighted(src, 0.3, result, 0.7, 0, dst);
    imshow("FCN-demo", dst);
    waitKey(0);
    return 0;
}
vector<Vec3b> readColor() {
    vector<Vec3b> colors;
    ifstream fp(label_txt_file);
    if (!fp.is_open()) {
        printf("could not open the file...\n");
        exit(-1);
    }
    string line;
    while (!fp.eof()) {
        getline(fp, line);
        if (line.length()) {
            stringstream ss(line);
            string name;
            ss >> name;
            int temp;
            Vec3b color;
            ss >>temp;
            color[0] = (uchar)temp;
            ss >>temp;
            color[1] = (uchar)temp;
            ss >>temp;
            color[2] = (uchar)temp;
            colors.push_back(color);
        }
    }
    return colors;
}