// 平面对象识别
/*
 步骤：
    1. 选择SURF特征，计算图像的特征点和描述子矩阵
    2. 选用Flann特征匹配，对两幅图像的特征描述子进行匹配描述，得到匹配点容器
    3. 得到最大最小匹配矩阵，得到最适合匹配的距离
    4. 根据两幅图像的适合匹配距离的关键点，得到关键点矩阵，利用 findHomography() - 发现两个平面的透视变换，生成变换矩阵
    5. 标定目标图像的四个点，利用perspectiveTransform()和变换矩阵H，求出变换后的图像四点
 */
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>

using namespace cv;
using namespace std;
using namespace cv::xfeatures2d;

int main(int argc, char** argv) {
    Mat src1 = imread("D:\\OpenCV core\\class1\\2.png");
    Mat src2 = imread("D:\\OpenCV core\\class1\\1.png");
    if(src1.empty())
    {
        printf("the image is empty");
        return -1;
    }
    imshow("src1",src1);
    imshow("src2",src2);

//    选择SURF特征
    int minHessian = 400;
    Ptr<SURF>detector = SURF::create(minHessian);
    vector<KeyPoint> keypoint_obj;
    vector<KeyPoint> keypoint_scene;        //输出关键点
    Mat descriptor_obj,descriptor_scene;  //输出描述子矩阵
    detector->detectAndCompute(src1,Mat(),keypoint_obj,descriptor_obj);
    detector->detectAndCompute(src2,Mat(),keypoint_scene,descriptor_scene);

//    matching
    FlannBasedMatcher matcher;
    vector<DMatch> matches;
    matcher.match(descriptor_obj,descriptor_scene,matches); //得到匹配容器

//    fing good matched points
    double minDist = 1000;
    double maxDist = 0;

    for(int i=0;i<descriptor_obj.rows;i++)  //find max min descriptor
     {
        double dist = matches[i].distance;
        if(dist > maxDist) {
            maxDist = dist;
        }
        if(dist < minDist) {
            minDist = dist;
        }
    }
    printf("max distance is %f\n",maxDist);
    printf("min distance is %f\n",minDist);

    vector <DMatch> goodMatches;  //存储距离的矩阵
    for(int i=0;i<descriptor_obj.rows;i++)
    {
        double dist = matches[i].distance;
        if(dist < max(2*minDist,0.02)) {
            goodMatches.push_back(matches[i]);
        }
    }
    Mat matchImg ;      //画出图像特征点相似连线
    drawMatches(src1,keypoint_obj,src2,keypoint_scene,goodMatches,matchImg,Scalar::all(-1),
            Scalar::all(-1), vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS
    );
//    imshow("matchImg",matchImg);

    vector<Point2f> obj;
    vector<Point2f> objInScene;
    for(size_t t=0;t<goodMatches.size();t++)
    {
        obj.push_back(keypoint_obj[goodMatches[t].queryIdx].pt);
        objInScene.push_back(keypoint_scene[goodMatches[t].trainIdx].pt);
    }
    Mat H = findHomography(obj,objInScene,RANSAC);  //找到相似的生成变换矩阵

    vector<Point2f> obj_corners(4);     //标定出图像的四个点
    vector<Point2f> objImg_corners(4);

    obj_corners[0] = Point(0,0);        //标定出图像的四个点
    obj_corners[1] = Point(src1.cols,0);
    obj_corners[2] = Point(src1.cols,src1.rows);
    obj_corners[3] = Point(0,src1.rows);
    perspectiveTransform(obj_corners,objImg_corners,H);  //图像相似在图像中找到已知图像

//    在源图像画出图像框
    line(matchImg,objImg_corners[0] + Point2f(src1.cols,0),objImg_corners[1] + Point2f(src1.cols,0),Scalar(0,0,255),2,8,0);
    line(matchImg,objImg_corners[1] + Point2f(src1.cols,0),objImg_corners[2] + Point2f(src1.cols,0),Scalar(0,0,255),2,8,0);
    line(matchImg,objImg_corners[2] + Point2f(src1.cols,0),objImg_corners[3] + Point2f(src1.cols,0),Scalar(0,0,255),2,8,0);
    line(matchImg,objImg_corners[3] + Point2f(src1.cols,0),objImg_corners[0] + Point2f(src1.cols,0),Scalar(0,0,255),2,8,0);

    imshow("matchImg",matchImg);
    waitKey(0);
    return 0;
}