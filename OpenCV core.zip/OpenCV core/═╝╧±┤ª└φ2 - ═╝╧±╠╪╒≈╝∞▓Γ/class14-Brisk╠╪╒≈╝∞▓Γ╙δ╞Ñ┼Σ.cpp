// Brisk特征检测与匹配
/* 原理：
    1. 构建尺度空间
    2. 特征点检测
    3. FAST9-16寻找特征点
    4. 特征点定位
    5. 关键点描述子

 步骤：

 */
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>

using namespace cv;
using namespace std;
using namespace cv::xfeatures2d;

int main(int argc, char** argv) {
    Mat src1 = imread("D:\\OpenCV core\\class1\\2.png",IMREAD_GRAYSCALE);
    Mat src2 = imread("D:\\OpenCV core\\class1\\1.png",IMREAD_GRAYSCALE);
    if(src1.empty())
    {
        printf("the image is empty");
        return -1;
    }
    imshow("src1",src1);
    imshow("src2",src2);

    Ptr<Feature2D> detector = BRISK::create();
    vector<KeyPoint> keypoints_1,keypoints_2;
    Mat descriptor_1,descriptor_2;
    detector->detectAndCompute(src1,Mat(),keypoints_1,descriptor_1);
    detector->detectAndCompute(src2,Mat(),keypoints_2,descriptor_2);
/* 描述子绘图
    RNG rng(123);
//    draw
    Mat result = src1.clone();
    cvtColor(result,result,CV_GRAY2BGR);
    for(size_t t=0; t<keypoints_1.size();t++)
    {
        circle(result,keypoints_1[t].pt ,2,Scalar(rng.uniform(0,255),rng.uniform(0,255),rng.uniform(0,255)),2,8,0);
    }
    imshow("result1",result);
//    drawKeypoints(src1,keypoints,result,Scalar::all(-1),DrawMatchesFlags::DEFAULT); 两种方式绘图
*/

// matching
    BFMatcher matcher(NORM_L2);
    vector<DMatch> matches;
    matcher.match(descriptor_1,descriptor_2,matches);

    // find good matched points
    double minDist = 1000;
    double maxDist = 0;
    for (int i = 0; i < descriptor_1.rows; i++) {
        double dist = matches[i].distance;
        if (dist > maxDist) {
            maxDist = dist;
        }
        if (dist < minDist) {
            minDist = dist;
        }
    }
    printf("max distance : %f\n", maxDist);
    printf("min distance : %f\n", minDist);
    vector<DMatch> goodMatches;
    for (int i = 0; i < descriptor_1.rows; i++) {
        double dist = matches[i].distance;
        if (dist < max(2 * minDist, 0.02)) {
            goodMatches.push_back(matches[i]);
        }
    }
//    draw matches
    Mat matchesImG;
    drawMatches(src1,keypoints_1,src2,keypoints_2,goodMatches,matchesImG,Scalar::all(-1),Scalar::all(-1),
                vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);
    imshow("matchesImG",matchesImG);


    waitKey(0);
    return 0;
}