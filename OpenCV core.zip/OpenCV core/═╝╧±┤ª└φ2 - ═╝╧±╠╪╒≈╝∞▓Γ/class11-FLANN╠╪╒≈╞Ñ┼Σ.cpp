// FLANN特征匹配
/*

 */
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>

using namespace cv;
using namespace std;
using namespace cv::xfeatures2d;

int main(int argc, char** argv) {
    Mat src1 = imread("D:\\OpenCV core\\class1\\1.png");
    Mat src2 = imread("D:\\OpenCV core\\class1\\2.png");
    if(src1.empty())
    {
        printf("the image is empty");
        return -1;
    }
    imshow("src1",src1);
    imshow("src2",src2);

//    选择SURF特征
    int minHessian = 400;
    Ptr<SURF>detector = SURF::create(minHessian);
    vector<KeyPoint> keypoint_obj;
    vector<KeyPoint> keypoint_scene;
    Mat descriptor_obj,descriptor_scene;
    detector->detectAndCompute(src1,Mat(),keypoint_obj,descriptor_obj);
    detector->detectAndCompute(src2,Mat(),keypoint_scene,descriptor_scene);

//    matching
    FlannBasedMatcher matcher;
    vector<DMatch> matches;
    matcher.match(descriptor_obj,descriptor_scene,matches);

//    fing good matched points
    double minDist = 1000;
    double maxDist = 0;

    for(int i=0;i<descriptor_obj.rows;i++)  //find max min descriptor
    {
        double dist = matches[i].distance;
        if(dist > maxDist)
        {
            maxDist = dist;
        }
        if(dist < minDist)
        {
            minDist = dist;
        }
    }
    printf("max distance is %f\n",maxDist);
    printf("min distance is %f\n",minDist);

    vector <DMatch> goodMatches;  //存储距离的矩阵
    for(int i=0;i<descriptor_obj.rows;i++)
    {
        double dist = matches[i].distance;
        if(dist < max(2*minDist,0.02))
        {
            goodMatches.push_back(matches[i]);
        }
    }
    Mat matchImg ;
    drawMatches(src1,keypoint_obj,src2,keypoint_scene,goodMatches,matchImg,Scalar::all(-1),
            Scalar::all(-1), vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS
    );
    imshow("matchImg",matchImg);


    waitKey(0);
    return 0;
}