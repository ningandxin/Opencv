//特征描述子与匹配-Brute-Force匹配
/*
图像处理步骤：
    1. 利用SURF特征点计算求出两幅图像的特征点和描述子
    2. BF匹配算子得到匹配矩阵
    3. 利用匹配算子得到匹配图像
 */
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>

using namespace cv;
using namespace std;
using namespace cv::xfeatures2d;

int main(int argc, char** argv) {
    Mat img1 = imread("D:\\OpenCV core\\class1\\1.png", IMREAD_GRAYSCALE);
    Mat img2 = imread("D:\\OpenCV core\\class1\\2.png", IMREAD_GRAYSCALE);
    if (!img1.data || !img2.data) {
        return -1;
    }
    imshow("image1", img1);
    imshow("image2", img2);

    int minHessian = 400;
    Ptr<SURF> detector = SURF::create(minHessian);  //SURF匹配
    vector<KeyPoint> keypoints_1;   //关键点
    vector<KeyPoint> keypoints_2;

    Mat descriptor_1, descriptor_2;
    detector->detectAndCompute(img1, Mat(), keypoints_1, descriptor_1);     //特征点计算
    detector->detectAndCompute(img2, Mat(), keypoints_2, descriptor_2);

    BFMatcher matcher(NORM_L2);     //匹配点归一化
    vector<DMatch> matches;
    matcher.match(descriptor_1, descriptor_2, matches);

    Mat matchesImg;
    drawMatches(img1, keypoints_1, img2, keypoints_2, matches, matchesImg);
    imshow("Descriptor Demo", matchesImg);

    waitKey(0);
    return 0;
}