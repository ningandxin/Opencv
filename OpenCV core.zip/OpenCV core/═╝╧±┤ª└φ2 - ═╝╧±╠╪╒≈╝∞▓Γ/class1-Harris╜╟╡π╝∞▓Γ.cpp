/*图像特征：
    可以表达图像中对象的主要信息、并且以此为依据从其他未知图像中检测出相似或者相同对象
    常用的图像特征：边缘、角点、纹理
*/
 //Harris角点检测
// E(u,v)=∑w(x,y)[I(x+u,y+v)-I(x,y)]^2
//E(u,v) = [u v] M [u v]'  M = ∑w(x,y)[Ix^2 IxIy IyIx Iy^2]
//角点响应R = det(M)-k(trace(M))^2 k = 0.04~0.06 可检测出每一个像素点是否为角点 dst(M) = rows*cols; trace(M) =rows + cols;
//API函数：cornerHarris(输入图像、输出图像、矩阵大小-2、窗口大小-3，k表示计算角度响应参数大小-0.04-0.06，过滤角度响应)

#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv;

Mat src,src_gray,dst;
int threshold_value = 130;
int threshold_max = 255;

void Harris_Demo(int, void *)
{
    Mat norm_dst,normScale_dst;
    dst = Mat ::zeros(src.size(),CV_32FC1);
    int blockSize = 2;
    int ksize = 3;
    double k = 0.04;
    cornerHarris(src_gray,dst,blockSize,ksize,k,BORDER_DEFAULT);    // Harris 特征点检测
    normalize(dst,norm_dst,0,255,NORM_MINMAX,CV_32FC1,Mat());
    convertScaleAbs(norm_dst,normScale_dst);        //转成


    Mat resultImg = src.clone();
    for(int row=0;row<resultImg.rows;row++)
    {
        uchar* currentRow = normScale_dst.ptr(row);
        for(int col=0;col<resultImg.cols;col++)
        {
            int value = (int)* currentRow;
            if(value> threshold_value)
            {
                circle(resultImg,Point(col,row),2,Scalar(0,255,0),2,8,0);
            }
            currentRow++;
        }
    }
    imshow("normScale_dst",resultImg);
}

int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }
    imshow("src",src);
    cvtColor(src,src_gray,CV_BGR2GRAY);

    createTrackbar("harris:","src",&threshold_value,threshold_max,Harris_Demo);
    Harris_Demo(0,0);

    waitKey(0);
    return 0;
}
