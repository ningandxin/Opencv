//Shi-Tomasi角点检测
//理论：与Harris角点检测唯一不同是最后角点表示为 R = min（Row，Col）
//API:goodFeatureToTrack(输入矩阵，输出矩阵，返回角点数目，表示最小可接受的向量值，两个角点之间最小距离（欧几里得距离）
//                        计算导数微分不同的窗口大小-3，是否使用Harris角点检测 )

#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv;

Mat src, gray_src;
int num_corners = 25;
int max_corners = 200;
void Tomasi_Demo(int, void*)
{
    Mat dst = Mat::zeros(src.size(),CV_32FC1);
    if(num_corners < 5 )
    {
        num_corners = 5;
    }
    vector<Point2f> corner;
    double aualityLevel = 0.01;
    double minDistance = 10;
    int blocksize = 3;
    bool useHarris = false;
    double k = 0.004;
    Mat resultImg = src.clone();
    imshow("result",resultImg);
    goodFeaturesToTrack(gray_src,corner,num_corners,aualityLevel,minDistance,Mat(),blocksize,useHarris,k);
    printf("numer of detected corners is %d\n",corner.size());

//    绘制
    for(size_t i =0;i <corner.size();i++)
    {
        circle(resultImg,corner[i],2,Scalar(0,0,255),2,8,0);
    }
    imshow("resultImg",resultImg);
}
int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }
    imshow("src",src);
    cvtColor(src,gray_src,CV_BGR2GRAY);

    createTrackbar("threshold ","src",&num_corners,max_corners,Tomasi_Demo);
    Tomasi_Demo(0,0);

    waitKey(0);
    return 0;
}
