// 级联分类器 - 人脸检测
/* 检测的基本原理
    1. 特征 = w1*(RectSum1)+w2 * (RectSum2)
    2. w1,w2是权重，可以是正或者负
    3. 对每个像素值，每个尺度上做计算
 */
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>

using namespace cv;
using namespace std;
using namespace cv::xfeatures2d;

int main(int argc, char** argv) {

    String cascadeFilePath = "G:\\opencv\\build\\etc\\haarcascades\\haarcascade_lefteye_2splits.xml";
    CascadeClassifier  face_cascade;
    if(!face_cascade.load(cascadeFilePath))
    {
        printf("could not load haar data ..\n");
        return -1;
    }
    Mat gray_src,resultImg;
    Mat src = imread("D:\\OpenCV core\\class1\\3.png");
    if(src.empty())
    {
        printf("the image is empty");
        return -1;
    }
    imshow("src1",src);
    cvtColor(src,gray_src,CV_BGR2GRAY);
    equalizeHist(gray_src,gray_src);

    vector<Rect> face;
    face_cascade.detectMultiScale(gray_src,face,1.1,2,0|CASCADE_SCALE_IMAGE,Size(30,30));

    for(size_t t=0;t<face.size();t++)
    {
        rectangle(src,face[t],Scalar(255,0,255),2,8,0);
    }
    imshow("src",src);
    waitKey(0);
    return 0;
}