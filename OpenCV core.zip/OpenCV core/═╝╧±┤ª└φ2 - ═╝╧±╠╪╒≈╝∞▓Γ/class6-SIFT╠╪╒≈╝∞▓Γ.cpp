//SIFT特征检测介绍
/*关键点特征：
    1.建立尺度空间，寻找极值
    2.关键点定位（寻找关键点准确位置与删除弱边缘）
    3.关键点方向指定
    4.关键点描述子
特征检测介绍：
    工作原理：
    建立尺度空间，寻找极值
        1. 建立图像金字塔，求取DOG，在每一级发现最大与最小值
        2. 构建高斯金字塔，每一层根据sigma的值不同，可以分为几个等级
    关键点精确定位
        3. 在像素级别获得了极值点的位置，更准确的值在亚像素的位置（关键点准确/精确定位）
        4. 删除弱边缘-通过Hassian矩阵特征值实现，小于阈值自动舍弃
     关键点方向指定
        5. 根据给定的图像窗口大小，求得每一层对应图像的梯度
        6. 计算每个高斯权重，sigma=scale*1.5, 0~360之间建立36个直方图bins
        7. 找到最高峰对应的bin，大于max*0.8的都保留
        8. 实现了旋转不变性，提高了匹配时候的稳定性
        9. 大概有15%的关键点会有多个方向
     关键点描述子
        10.拟合多项式插值寻找最大Peak
        11 得到描述子 = 4*4*8 = 128

代码实现：

 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

const char* output = "output";
Mat src, gray_src;

int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }
    imshow("src",src);

// SIRF特征检测
    int minHessian = 400;
    Ptr<SIFT> detector = SIFT::creste(minHessian);
    vector<KeyPoint> keypoints;
    detector ->detect(src,keypoints);

    Mat keypoint_img;
    drawKeypoints(src,keypoints,keypoint_img);
    imshow("keypoints",keypoints);


    waitKey(0);
    return 0;
}
