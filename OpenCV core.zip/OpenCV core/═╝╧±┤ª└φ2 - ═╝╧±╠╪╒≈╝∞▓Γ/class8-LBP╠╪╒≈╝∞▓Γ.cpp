//LBP（Local Binary Patterns）
/*
    LBP表达：
        周围像素点，小于中间阈值就为0，大于中间阈值就为1，顺时针读取二进制像素值
        LBP 为二进制像素点*周围权重值
        C = （像素大于中心阈值的值求和）/数量 - （小于中心阈值的值求和）/数量   对比度
    LBP扩展与多尺度表达
    LBP
代码实现：
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

Mat src ,src_gray, dst;
const char* output = "output";

int lbp_value = 3;
int lbp_max = 20;

void LBP_demo(int, void*)
{
    int offset = lbp_value * 2;
    Mat elbpImg = Mat::zeros(src_gray.rows-offset,src_gray.cols - offset,CV_8UC1);
    int width = src_gray.cols;
    int height = src_gray.rows;

    int num_Neighbors = 8;
    for(int n = 0; n<8; n++)
    {
        float x = static_cast<float>(lbp_value)*cos(2.0*CV_PI * n / static_cast<float>(num_Neighbors));
        float y = static_cast<float>(lbp_value)*-sin(2.0*CV_PI * n / static_cast<float>(num_Neighbors));
        int fx = static_cast<int>(floor(x));
        int fy = static_cast<int>(floor(y));
        int cx = static_cast<int>(ceil(x));
        int cy = static_cast<int>(ceil(y));

        float ty = y - fy;
        float tx = x - fx;

        float w1 = (1 -tx)*(1-ty) ;
        float w2 = (tx)*(1-ty);
        float w3 = (1-tx)*(ty);
        float w4 = (tx)*(ty);

        for(int row = lbp_value;row < (height - lbp_value);row++)
        {
            for(int col = lbp_value;col<(width - lbp_value);col++)
            {
                float t = w1*src_gray.at<uchar >(row+fy,col+fx)+ w2*src_gray.at<uchar >(row+fy,col+cx)+
                           w3*src_gray.at<uchar >(row+cy,col+fx)+w4*src_gray.at<uchar >(row+cy,col+cx);

                elbpImg.at<uchar>(row - lbp_value,col -lbp_value) += ((t>src_gray.at<uchar>(row,col))&&(abs(t-src_gray.at<uchar>(row,col))>std::numeric_limits<float>::epsilon()))<<n;
            }
        }
        imshow("elbpImg",elbpImg);
    }
}
int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }
    imshow("src",src);
    cvtColor(src,src_gray,CV_BGR2GRAY);
    int width = src_gray.cols;
    int height = src_gray.rows;

    Mat lbpImage = Mat::zeros(height-2,width-2,CV_8UC1); //为什么减2
    for(int row = 1;row <height-1;row++)
    {
        for(int col=1;col<width -1;col++)
        {
            uchar c =src_gray.at<uchar>(row,col) ;
            uchar code = 0;
            code|=((src_gray.at<uchar>(row-1,col-1)>c))<< 7;
            code|=((src_gray.at<uchar>(row-1,col)>c))<< 6;
            code|=((src_gray.at<uchar>(row-1,col+1)>c))<< 5;
            code|=((src_gray.at<uchar>(row,col+1)>c))<< 4;
            code|=((src_gray.at<uchar>(row+1,col+1)>c))<< 3;
            code|=((src_gray.at<uchar>(row+1,col)>c))<< 2;
            code|=((src_gray.at<uchar>(row+1,col-1)>c))<< 1;
            code|=((src_gray.at<uchar>(row,col-1)>c))<< 0;
            lbpImage.at<uchar>(row-1,col-1) = code;
        }
    }

//    ELBP 演示
    createTrackbar("LBP is","src",&lbp_value,lbp_max,LBP_demo);
    LBP_demo(0,0);
    imshow("output",lbpImage);
    waitKey(0);
    return 0;
}
