//HOG特征（方向梯度直方图描述子）检测
/*
HOG特征描述子提取
    1. 灰度图像转换  cvtColor
    2. 梯度计算      Soble算子
    3. 分网络的梯度方向直方图
        (1) 分割为8*8=64像素的cell网格
        (2) 对每个cell求取方向直方图 角度 = a*tan2(求导y/x)
        (3) 分为9个Bin，角度取值范围为-180~180之间，对-180~0之间的加上180取整数，对应的值为梯度值
    4. 块描述子
        将每个cell的直方图组合成为一个大的直方图（Bin 索引不变[0~9]之间）
    5. 块描述子归一化
        基于L2实现描述子归一化，归一化因子计算为
    6. 特征数据与检测窗口
        （1）最终获得HOG描述算子（特征数据）
        （2）需要正向训练个200个左右的特征样本
        （3）反向训练600~800个左右的特征样本
        （4）初步测试、开窗检测
        对于64*128的像素块，可以分成8*16个Cell分为7*15个HOG块，总计的直方图向量数为 8*16*2*2*9 = 3780
    7. 匹配方法
        SVM
API方法：HOGDEscriptor::HOGDescriptor
代码实现：
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

const char* output = "output";

int main(int argc, char* argv)
{
    Mat src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }
    imshow("src",src);

    /* 特征向量检测次数
    Mat dst, dst_gray;
    resize(src, dst, Size(64, 128));
    cvtColor(dst, dst_gray, COLOR_BGR2GRAY);
    HOGDescriptor detector(Size(64, 128), Size(16, 16), Size(8, 8), Size(8, 8), 9);

    vector<float> descriptors;
    const vector<Point> locations;
    detector.compute(dst_gray, descriptors, Size(0, 0), Size(0, 0), locations);
    printf("number of HOG descriptors : %d", descriptors.size());
*/
//    Hog特征检测用SVM
    HOGDescriptor hog = HOGDescriptor();
    hog.setSVMDetector(hog.getDefaultPeopleDetector());

    vector<Rect> findLocations;
    hog.detectMultiScale(src,findLocations,0,Size(8,8),Size(32,32),1.05,2.0, false); //多尺度检测
    Mat result = src.clone();
    for(size_t t=0;t<findLocations.size();t++)
    {
        rectangle(result,findLocations[t],Scalar(0,0,255),2,8,0);
    }
    imshow("result",result);

    waitKey(0);
    return 0;
}
