//亚像素级别角点检测
//提高检测精确度，实际上所有角点不会是一个真正的准确像素点
//亚像素定位：插值方法、基于图像矩计算、曲线拟合方法-（高斯曲线、多项式、椭圆曲线）
//步骤：先检测到角点再利用方法进行定位
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv;

const char* output = "output";
Mat src, gray_src;
int max_corcers = 30;
int max_count = 50;
void SubPix_Demo(int,void*);
int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }
    imshow("src",src);

    cvtColor(src,gray_src,CV_BGR2GRAY);
    createTrackbar("Point","src",&max_corcers,max_count,SubPix_Demo);
    SubPix_Demo(0,0);
    waitKey(0);
    return 0;
}
void SubPix_Demo(int,void*)
{
    if(max_corcers <5)
    {
        max_corcers = 5;
    }
    vector<Point2f> corcers;
    double qualityLevel = 0.01;
    double minDistance = 10;
    int blockSize = 3;
    double k = 0.04;
    goodFeaturesToTrack(gray_src,corcers,max_corcers,qualityLevel,minDistance,Mat(),blockSize, false,k);
    cout <<"numer"<< corcers.size()<<endl;
    Mat resultImg = src.clone();
    for(size_t i = 0; i < corcers.size(); i++)
    {
        circle(resultImg,corcers[i],2,Scalar(0,0,255),2,8,0);
    }
    imshow(output,resultImg);

    Size winSize  = Size(5,5);
    Size zeroSize  = Size(-1,-1);
    TermCriteria tc = TermCriteria(TermCriteria::EPS + TermCriteria::MAX_ITER,40,0.001);
    cornerSubPix(gray_src,corcers,winSize,zeroSize,tc);

    for(size_t i=0; i<corcers.size();i++)
    {
        cout <<(i+1) << "point[x,y]"<<corcers[i].x<<","<<corcers[i].y<<endl;
    }
    return ;
}