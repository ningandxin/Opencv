// AKAZA特征局部匹配
/* 原理：
    1. AOS构造尺度空间
    2. Hessian矩阵特征点检测
    3. 基于一阶微分图像指定方向
    4. 描述子生成
 与SIFT、SURF比较：
    1. 更加稳定
    2. 非线性尺度空间
    3. AKAZE速度更快
 步骤：

 */
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>

using namespace cv;
using namespace std;
using namespace cv::xfeatures2d;

int main(int argc, char** argv) {
    Mat src1 = imread("D:\\OpenCV core\\class1\\2.png");
    Mat src2 = imread("D:\\OpenCV core\\class1\\1.png");
    if(src1.empty())
    {
        printf("the image is empty");
        return -1;
    }
    imshow("src1",src1);
    imshow("src2",src2);

    Ptr<AKAZE> detector = AKAZE::create();
    vector<KeyPoint> keypoints_1;
    vector<KeyPoint> keypoints_2;
    Mat descriptor1,descriptor2;

    double t1 = getTickCount();         //获得时间
    detector->detectAndCompute(src1,Mat(),keypoints_1,descriptor1);    //检测到特征点
    detector->detectAndCompute(src2,Mat(),keypoints_2,descriptor2);    //检测到特征点
    double t2 = getTickCount();
    double tkaze = 1000 * (t2 -t1)/getTickFrequency();
    printf("KAZA :%f",tkaze);

//    matching
    BFMatcher matcher(NORM_L2);
    vector<DMatch> matches;
    matcher.match(descriptor1,descriptor2,matches);

    Mat keyPointImg;
    drawMatches(src1,keypoints_1,src2,keypoints_2,matches,keyPointImg);
    double minDist = 1000;
    double maxDist = 0;

    for(int i=0;i<descriptor1.rows;i++)  //find max min descriptor
    {
        double dist = matches[i].distance;
        if(dist > maxDist) {
            maxDist = dist;
        }
        if(dist < minDist) {
            minDist = dist;
        }
    }
    vector <DMatch> goodMatches;  //存储距离的矩阵
    for(int i=0;i<descriptor1.rows;i++)
    {
        double dist = matches[i].distance;
        if(dist < max(2*minDist,0.02))
        {
            goodMatches.push_back(matches[i]);
        }
    }
    drawMatches(src1,keypoints_1,src2,keypoints_2,goodMatches,keyPointImg,Scalar::all(-1),
                Scalar::all(-1),vector<char>(),DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);
    imshow("keyPointImg",keyPointImg);

    waitKey(0);
    return 0;
}