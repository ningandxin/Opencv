//SURF特征检测
//特征关键特性：特征检测、尺度空间、旋转不变性、特征向量
/*特征检测介绍：
    工作原理：
        1. 选择图像中的POI（Point of Interest）Hessian Matrix [ ((Ix)^2)' Ix'Iy' Iy'Ix' (IxIx)'] ~
            Dxx[1 -2 1] Dyy = [1 -2 1]' Dxy = [-1 1 1 -1]
        2. 在不同的尺度空间发现关键点。非最大信号压制
           （x = -(H二阶导)^-1 (H的一阶导) 整数每次逼近0.5，直到逼近小数坐标）
        3. 发现特征点方法、旋转不变性要求
        4. 生成特征向量   v = {∑dx，∑|dx|，∑dy，∑|dy|} （归一化后光照不变性）
 */
/*
    代码实现：
        1. SURF特征提取代码演示
        2. upright0 - 表示计算选择不变性，1表示不计算，速度更快
        3. HessianThreshold默认值在300~500之间
        4. Octaves - 4表示在四个尺度空间
        5. OctaveLayers - 表示每个尺度的层数
 */
#include <opencv2/opencv.hpp>
#include <opencv2/xfeatures2d.hpp>
#include <iostream>

using namespace cv;
using namespace cv::xfeatures2d;
using namespace std;

const char* output = "output";
Mat src, gray_src;

int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }
    imshow("src",src);

// SURF特征检测
    int minHessian = 400;
    Ptr<SURF> detector = SURF::creste(minHessian);
    vector<KeyPoint> keypoints;
    detector ->detect(src,keypoints);

    Mat keypoint_img;
    drawKeypoints(src,keypoints,keypoint_img);
    imshow("keypoints",keypoints);


    waitKey(0);
    return 0;
}
