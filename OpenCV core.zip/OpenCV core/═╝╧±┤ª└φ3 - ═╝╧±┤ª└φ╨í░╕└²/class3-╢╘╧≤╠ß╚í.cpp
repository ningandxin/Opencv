// 案例三：对图像中对象进行提取，获取这样对象，去掉其他干扰和非目标对象
//解决思路：二值分割 + 形态学处理 + 连通区域 +　横纵比计算
//
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

Mat src,binaryImg,dst;
int threshold_value = 100;
int threshold_max = 200;

int main(int argc, char** argv) {

    src = imread("D:\\OpenCV core\\class1\\case4.png",IMREAD_GRAYSCALE);
    if(!src.data)
    {
        printf("the image is empty\n");
        return -1;
    }
    imshow("src",src);
//    二值化
    threshold(src,binaryImg,0,255,THRESH_BINARY|THRESH_OTSU);
//    形态学操作:关操作 进行连通
    Mat kernel = getStructuringElement(MORPH_RECT,Size(5,5),Point(-1,-1));
    morphologyEx(binaryImg,dst,MORPH_CLOSE,kernel);
    imshow("close Img",dst);
//    形态学操作:开操作 滤掉小噪点
    kernel = getStructuringElement(MORPH_RECT,Size(7,7),Point(-1,-1));
    morphologyEx(binaryImg,dst,MORPH_OPEN,kernel);
    imshow("open Img",dst);
//  发现轮廓观察面积大小
    vector<vector<Point>> contours;
    vector<Vec4i> hieracy;
    findContours(dst,contours,hieracy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(0,0));
//  绘制轮廓图像
    Mat resultImg = Mat::zeros(src.size(),CV_8UC3);
    for(size_t t=0; t < contours.size();t++)
    {
//       面积过来
        double area = contourArea(contours[t]);
        if(area < 100) continue;
//        横纵过滤
        Rect rect = boundingRect(contours[t]);
        float ratio = float(rect.width)/float(rect.height);
        if(ratio<1.1 && ratio >0.9)
        {
            drawContours(resultImg,contours,t,Scalar(2,2,255),2,8,Mat(),0,Point(0,0));
            printf("circle area %f\n",area);
            printf("circle length %f\n",arcLength(contours[t], true));
            int x = rect.x + rect.width/2;
            int y = rect.y + rect.height/2;
            circle(resultImg,Point(x,y),2,Scalar(0,0,255),2,8,0);
        }
    }
    imshow("resultImg",resultImg);
/*
 //    检测到圆
    vector<Vec3f> myCircles;
    cvtColor(resultImg,resultImg,CV_BGR2GRAY);
    HoughCircles(resultImg,myCircles,HOUGH_GRADIENT,1,7,50,32,20,80);
    cout<<myCircles.size() <<endl;
    Mat dstImg = src.clone();
    cvtColor(dstImg,dstImg,CV_GRAY2BGR);
    for(int i=0; i<myCircles.size();i++)
    {
        Vec3f circleInfo = myCircles[i];
        circle(dstImg,Point(circleInfo[0],circleInfo[1]),circleInfo[2],Scalar(0,0,255),2,8,0);
    }
    imshow("dstImg",dstImg);
*/
    waitKey(0);
    return 0;
}
