// 案例五 ：透视校正 拍摄或扫描图像不是规则的矩阵，会对后期处理产生不好影响，需要透过透视变换校正得到正确形状
//解决方案：通过二值分割 + 形态学方法 +Ｈｏｕｇｈ直线检测 + 透视校正　
/*步骤：
    1. 二值化图像分割背景与目标对象
    2. 形态学闭操作，将内部轮廓填充
    3. 发现轮廓并绘制轮廓图像
    4. 利用霍夫直线检测轮廓直线
    5. 寻找图像中的上下左右四条直线
    6. 利用直线求斜率与截距
    7. 利用斜率与截距求出四个坐标角点
    8. 利用四个坐标角点与要生成的四个角点生成透视变换矩阵
    9. 利用透视变换API校正图像
 */
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;


int main(int argc, char** argv) {

    Mat gray_src, binary, dst;
    Mat src = imread("D:\\OpenCV core\\class1\\case6.png");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);

//    二值图像分割
    cvtColor(src,gray_src,CV_BGR2GRAY);
    threshold(gray_src,binary,0,255,THRESH_BINARY_INV|THRESH_OTSU);

//  形态学闭操作
    Mat kernel = getStructuringElement(MORPH_RECT,Size(5,5),Point(-1,-1));
    morphologyEx(binary,dst,MORPH_CLOSE,kernel,Point(-1,-1),3);
//    imshow("dst image", dst);

//    寻找最大的轮廓
    bitwise_not(dst,dst,Mat());
    vector<vector<Point>> contours;
    vector<Vec4i> hierachy;
    findContours(dst,contours,hierachy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point());
//    绘制轮廓
    int width = src.cols;
    int height = src.rows;
    Mat drawImg = Mat :: zeros(src.size(),CV_8UC3);
    for(size_t t=0; t< contours.size(); t++) {
        Rect rect = boundingRect(contours[t]);
        if(rect.width > width/2 && rect.height > height/2 && rect.width <width - 5 )
        {
          drawContours(drawImg,contours,t,Scalar(0,0,255),1,LINE_AA,hierachy,0);
        }
    }
//    imshow("drawImg image", drawImg);
//   霍夫直线检测
    vector<Vec4i> lines;
    Mat contoursImg ;
    int accu = min(width/2,height/2);
    cvtColor(drawImg,contoursImg,CV_BGR2GRAY);
    HoughLinesP(contoursImg,lines,1,CV_PI/180.0,accu,accu,0);

    Mat linesImg = Mat::zeros(src.size(),CV_8UC3);
    for(size_t t=0; t<lines.size(); t++)
    {
        Vec4i ln = lines[t];
        line(linesImg,Point(ln[0],ln[1]),Point(ln[2],ln[3]),Scalar(0,0,255),2,8,0);
    }
    cout << lines.size() <<endl;
//    imshow("linesImg",linesImg);
//    寻找与定位上下左右四条直线
    int deltah = 0;
    Vec4i topLine,BootmLines;
    Vec4i leftLines,rightLines;
    for(int i=0; i<lines.size(); i++)
    {
        Vec4i ln = lines[i];
        deltah = abs(ln[3] - ln[1]);
        if(ln[3] < height/2 && ln[1]<height/2 && deltah < accu -1) {
            topLine = lines[i];
            if(topLine[3] > ln[3] && topLine[3] > 0){
                topLine = lines[i];
            }
        }
        if(ln[3] > height/2 && ln[1]>height/2 && deltah < accu -1) {
            BootmLines = lines[i];
        }
        if(ln[0] < width/2 && ln[2]<width/2 ) {
            leftLines = lines[i];
        }
        if(ln[0] >width/2 && ln[2]>width/2 ) {
            rightLines = lines[i];
        }
    }
    cout <<"top line:p1(x,y) : =" <<topLine[0]<<" "<<topLine[1] <<"p2(x,y) :" <<topLine[2]<<" "<<topLine[3]<<endl;
    cout <<"bootm line:p1(x,y): =" <<BootmLines[0]<<" "<<BootmLines[1]<<"p2(x,y) :" <<BootmLines[2]<<" "<<BootmLines[3]<<endl;
    cout <<"left line:p1(x,y): =" <<leftLines[0]<<" "<<leftLines[1]<<"p2(x,y) :" <<leftLines[2]<<" "<<leftLines[3]<<endl;
    cout <<"right line:p1(x,y): =" <<rightLines[0]<<" "<<rightLines[1]<<"p2(x,y) :" <<rightLines[2]<<" "<<rightLines[3]<<endl;
//    拟合四条直线方程
    float k1,c1;
    k1 = float(topLine[3] - topLine[1])/float(topLine[2] - topLine[0]);
    c1 = topLine[1] - k1 * topLine[0];
    float k2,c2;
    k2 = float(BootmLines[3] - BootmLines[1])/float(BootmLines[2] - BootmLines[0]);
    c2 = BootmLines[1] - k2 * BootmLines[0];
    float k3,c3;
    k3 = float(leftLines[3] - leftLines[1])/float(leftLines[2] - leftLines[0]);
    c3 = leftLines[1] - k3 * leftLines[0];
    float k4,c4;
    k4   = float(rightLines[3] - rightLines[1])/float(rightLines[2] - rightLines[0]);
    c4 = rightLines[1] - k4 * rightLines[0];

//    求出四条直线的交点
    Point P1; //左上角
    P1.x = static_cast<int>(c1 - c3)/(k3 - k1);
    P1.y =  static_cast<int>(k3*P1.x + c3);
    Point P2;
    P2.x = static_cast<int>(c1 - c4)/(k4 - k1);
    P2.y =  static_cast<int>(k1*P2.x + c1);
    Point P3;
    P3.x = static_cast<int>(c2 - c3)/(k3 - k2);
    P3.y =  static_cast<int>(k3*P3.x + c3);
    Point P4;
    P4.x = static_cast<int>(c2 - c4)/(k4 - k2);
    P4.y =  static_cast<int>(k2*P4.x + c2);

    cout << P1.x <<" "<<P1.y<<endl;
    cout << P2.x <<" "<<P2.y<<endl;
    cout << P3.x <<" "<<P3.y<<endl;
    cout << P4.x <<" "<<P4.y<<endl;
//  显示四个点的坐标
    circle(linesImg,P1,2,Scalar(0,255,0),2,8,0);
    circle(linesImg,P2,2,Scalar(0,255,0),2,8,0);
    circle(linesImg,P3,2,Scalar(0,255,0),2,8,0);
    circle(linesImg,P4,2,Scalar(0,255,0),2,8,0);
//    imshow("lines",linesImg);
//  透视变换
    vector<Point2f> src_corners(4);
    src_corners[0] = P1;
    src_corners[1] = P2;
    src_corners[2] = P4;
    src_corners[3] = P3;

    vector<Point2f> dst_corners(4);
    dst_corners[0] = Point(0,0);
    dst_corners[1] = Point(width,0);
    dst_corners[2] = Point(width,height);
    dst_corners[3] = Point(0,height);

//   获取透视变换矩阵
    Mat ResultImg;
    Mat warpmatrix = getPerspectiveTransform(src_corners,dst_corners);
    warpPerspective(src,ResultImg,warpmatrix,ResultImg.size(),INTER_LINEAR);
    imshow("ResultImg",ResultImg);

    waitKey(0);
    return 0;
}
