// 案例一：寻找英语试卷填空题的下划线，这个对后期的切图与自动识别比较重要
//解决思路：
//        通过图像形态学操作来寻找直线，霍夫获取位置信息与显示
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;

Mat src,src1,src_gray,dst,roiImage;
int threshold_value = 100;
int threshold_max = 200;
void Detect_Lines(int, void*);
void morhpologyLines(int,void*);
int main(int argc, char** argv) {

    src = imread("D:\\OpenCV core\\class1\\case3.png",IMREAD_GRAYSCALE);
    if(!src.data)
    {
        printf("the image is empty\n");
        return -1;
    }
    Rect roi = Rect(10,10,src.cols-20,src.rows-20);
    roiImage = src(roi);
    imshow("roiImage",roiImage);
//    createTrackbar("threshold","roiImage",&threshold_value,threshold_max,Detect_Lines);
//    Detect_Lines(0,0);
    morhpologyLines(0,0);
    waitKey(0);
    return 0;
}

void Detect_Lines(int, void*)
{
//    cvtColor(src,src_gray,CV_BGR2GRAY);
    Canny(roiImage,dst,threshold_value,threshold_max,3);
    vector<Vec4i> lines;
    HoughLinesP(dst,lines,1,CV_PI/180.0,30,30,0);

    cvtColor(dst,dst,CV_GRAY2BGR);
    for(size_t t=0; t< lines.size(); t++)
    {
        Vec4i ln = lines[t];
        line(dst,Point(ln[0],ln[1]),Point(ln[2],ln[3]),Scalar(0,0,255),2,8);
    }
    imshow("dst",dst);
}
void morhpologyLines(int,void*)
{
//    binary image
    Mat binaryImg,morhpImg;
    threshold(roiImage,binaryImg,0,255,THRESH_BINARY_INV|THRESH_OTSU);

//  morphology operation
    Mat kernel = getStructuringElement(MORPH_RECT,Size(35,1),Point(-1,-1));
    morphologyEx(binaryImg,morhpImg,MORPH_OPEN,kernel,Point(-1,-1));

//  dilate images
    kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));
    dilate(morhpImg,morhpImg,kernel);
//  hough lines

    vector<Vec4i>lines;
    HoughLinesP(morhpImg,lines,1,CV_PI/180.0,30,20,0);
    Mat resultImg = roiImage.clone();
    cvtColor(resultImg,resultImg,CV_GRAY2BGR);
    for(size_t t=0; t< lines.size(); t++)
    {
        Vec4i ln = lines[t];
        line(resultImg,Point(ln[0],ln[1]),Point(ln[2],ln[3]),Scalar(0,255,255),2,8);
    }
    imshow("resultImg",resultImg);
}