// 案例六：照片来自太空望远镜的星云图像，科学家想知道它的面积和周长
// 解决思路：二值化 + 形态学操作 + 轮廓提取
#include <opencv2/opencv.hpp>
#include <iostream>

using namespace cv;
using namespace std;


int main(int argc, char** argv) {

    Mat gray_src, binary, dst;
    Mat src = imread("D:\\OpenCV core\\class1\\case7.png");
    if (src.empty()) {
        printf("could not load image...\n");
        return -1;
    }
    namedWindow("input image", CV_WINDOW_AUTOSIZE);
    imshow("input image", src);

//  高斯模糊
    Mat blurImage;
    GaussianBlur(src,blurImage,Size(15,15),0,0);

//  二值化
    cvtColor(blurImage,gray_src,CV_BGR2GRAY);
    threshold(gray_src,binary,0,255,THRESH_BINARY|THRESH_TRIANGLE);
    imshow("binary image", binary);

//  形态学操作 开操作：边缘断开 闭操作：小孔填上
    Mat morphImage;
    Mat kernel = getStructuringElement(MORPH_RECT,Size(3,3),Point(-1,-1));
    morphologyEx(binary,morphImage,MORPH_CLOSE,kernel,Point(-1,-1),2);
     imshow("morphImage ", morphImage);

//  获取最大轮廓
    vector<vector<Point>> contours;
    vector<Vec4i> hierachy;
    findContours(morphImage,contours,hierachy,CV_RETR_EXTERNAL,CHAIN_APPROX_SIMPLE);
    Mat conImg = Mat :: zeros(src.size(),CV_8UC3);
    for(size_t t=0; t< contours.size(); t++)
    {
        Rect rect = boundingRect(contours[t]);  //最大外接矩阵
        if(rect.width < src.cols/2) continue;
        if(rect.width > src.cols - 20) continue;
        double area = contourArea(contours[t]);     //区域面积
        double len = arcLength(contours[t], true);      //区域周长
        drawContours(conImg,contours,t,Scalar(0,255,0),1,8,Mat(),0);    //绘制轮廓
        printf("area is %f\n",area);
        printf("len is %f\n",len);
    }
    imshow("conImg ", conImg);
    waitKey(0);
    return 0;
}
