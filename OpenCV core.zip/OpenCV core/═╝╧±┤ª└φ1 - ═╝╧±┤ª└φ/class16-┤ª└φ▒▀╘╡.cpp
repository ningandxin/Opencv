//卷积处理边缘
//处理边缘的方式：
//填充边缘用指定像素值、用已知的边缘像素值、用另一边的像素来补偿填充、增加一个边缘
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;


int main(int argc, char* argv)
{
    Mat dst;
    Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\2.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);

    int top = (int)(0.05 * src.rows);
    int bottom = (int)(0.05 * src.rows);
    int left = (int)(0.05 * src.cols);
    int right = (int)(0.05 * src.cols);
    RNG rng(12345); //随机
    int bordertype = BORDER_DEFAULT;

    int c = 0;
    while(true)
    {
        c = waitKey(500);
        if((char)c == 27)
        {
            break;
        }
        if((char)c == 'q')
        {
            bordertype = BORDER_REPLICATE;
        } else if((char)c == 'w')
        {
            bordertype = BORDER_WRAP;
        }else if((char)c == 'e')
        {
            bordertype = BORDER_CONSTANT;
        }
        Scalar color = Scalar(rng.uniform(0,255),rng.uniform(0,255),rng.uniform(0,255));
        copyMakeBorder(src,dst,top,bottom,left,right,bordertype,color);
        imshow("dst",dst);
    }
    waitKey(0);
    return 0;

}
