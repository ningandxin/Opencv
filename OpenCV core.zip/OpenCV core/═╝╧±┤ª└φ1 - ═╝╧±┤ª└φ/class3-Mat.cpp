//Mat 对象
//克隆 copeto()函数和clone()函数
//create()函数可以创建与原图像一样大小图像
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
    Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\3.jpg",-1);
    if(!src.data)
    {
        printf("image is empty");
        return -1;
    }
    imshow("src",src);

    Mat dst;
//    dst = Mat(src.size(),src.type());
//    dst = Scalar(127,0,255);
//    imshow("output",dst);
    //克隆 copeto()函数和clone()函数
//    Mat dst = src.clone();
    cvtColor(src,dst,CV_BGR2GRAY);
    int cols = dst.cols;
    int rows = dst.rows;
    cout << cols <<" "<<rows<<endl;
    const uchar* firstRow = dst.ptr<uchar>(0);
    printf("%d\n",*firstRow);


    Mat M(100,100,CV_8UC3,Scalar(0,0,255));
    Mat m1;
    m1.create(src.size(),src.type());
    m1 = Scalar(0,0,255);
    imshow("output",m1);
    waitKey(0);
    return 0;
}