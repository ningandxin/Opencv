//霍夫变换-直线检测 HoughLines()
//霍夫变换直线检测概率 HoughLinesP()最终输出是直线的两个点(x0,y0,x1,y1)
//前提条件边缘检测已经完成：平面空间到霍夫极坐标空间转换
/*原理：
    平面坐标空间中直线对应极坐标空间中无数曲线相交的一点，r对应直线角度
    CV::HoughLinesP(输入图像，输出图像，像素扫描步长，角度步长一般取CV_PI/180，
    阈值只有获得足够交点的点才看做直线，最小直线长度，最大间隔)
*/
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{

    Mat src_gray,dst;
    Mat src = imread("C:\\Users\\LXN\\Desktop\\1.png",1);
    if(src.empty())
    {
        return -1;
        printf("image1 is empty ");
    }
    imshow("src",src);
    Canny(src,src_gray,150,300,3);
    cvtColor(src_gray,dst,CV_GRAY2BGR);
    imshow("src_gray",src_gray);


    vector<Vec4f>plines;
    HoughLinesP(src_gray,plines,1,CV_PI/188,10,0,10);
    Scalar color = Scalar(0,0,255);
    for(size_t i=0;i<plines.size();i++)
    {
        Vec4f hlines = plines[i];
        line(dst,Point(hlines[0],hlines[1]),Point(hlines[2],hlines[3]),color,1,LINE_AA);
    }

    imshow("dst",dst);
    waitKey(0);
    return 0;

}
