//线性混合操作
//理论上线性混合操作  g(x)=(1-a)f0(x)+a*f1(x)
//相关API（addWeighted）
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
    Mat src1,src2 ,dst;
     src1 = imread("C:\\Users\\LXN\\Desktop\\photo\\3.jpg",-1);
     src2 = imread("C:\\Users\\LXN\\Desktop\\photo\\our1.jpg",-1);

    if(!src1.data)
    {
        printf("image1 is empty ");
        return -1;
    }
    if(!src2.data)
    {
        printf("image2 is empty ");
        return -1;
    }
    double alpha = 0.5;
    if(src1.rows==src2.rows && src1.cols == src2.cols && src1.channels()==src2.channels())
    {
        imshow("1",src1);
        imshow("2",src2);
        addWeighted(src1,alpha,src2,(1-alpha),0.0,dst);
        imshow("out",dst);
    } else
    {
        printf("the size of image is not same ...\n");
    }
    waitKey(0);
    return 0;
}