//图像金字塔:上采样和降采样
//高斯金字塔-用来对图像进行降采样
//生成过程：1.对当前层进行高斯模糊 2.删除当前层的偶数行与列
//高斯不同(DOG)：把同一张图像在不同的参数下做高斯模糊之后的结果相减，得到的输出图像
//拉普拉斯金字塔-用来重建一张图像
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;
char OUT_WIN[] = "output image";

int main(int argc, char* argv)
{
  Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);
    //对输入图像进行上采样
    Mat dst;
    pyrUp(src,dst,Size(src.cols*2,src.rows*2));
//    imshow("dst",dst);
    //降采样
    Mat s_down;
    pyrDown(src,s_down,Size(src.cols/2,src.rows/2));
//    DOG高斯不同图像 对不同参数下的高斯模糊图像进行相减
    Mat g1,g2,gray_src,tree_Img;
    cvtColor(src,gray_src,CV_BGR2GRAY);
    GaussianBlur(gray_src,g1,Size(3,3),0,0);
    GaussianBlur(g1,g2,Size(3,3),0,0);
    subtract(g1,g2,tree_Img,Mat());
//    归一化显示
    normalize(tree_Img,tree_Img,255,0,NORM_MINMAX);
    imshow("treeImg",tree_Img);
    waitKey(0);
    return 0;
}
