//阈值操作（Threshold）
//阈值类型：阈值反二值化、截断、阈值取0
//寻找阈值方法：OTSU、TRIANGLE
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;
char OUT_WIN[] = "output image";
Mat src,dst;
Mat gray_src;
int threshold_value = 127;
int type_value = 2;
int threshold_max = 255;
int type_max = 4;

void Threshold_Demo(int,void*)
{
    threshold(gray_src,dst,threshold_value,threshold_max,THRESH_TRIANGLE|type_value);
    imshow(OUT_WIN,dst);
}

int main(int argc, char* argv)
{
  Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);
    namedWindow(OUT_WIN,WINDOW_AUTOSIZE);
    cvtColor(src,gray_src,CV_BGR2GRAY);
    createTrackbar("Threshold:",OUT_WIN, &threshold_value,threshold_max,Threshold_Demo);
    createTrackbar("Type value:",OUT_WIN, &type_value,type_max,Threshold_Demo);
    Threshold_Demo(0,0);

    waitKey(0);
    return 0;
}
