//形态学操作 主要针对二值图像
//开操作-open   先腐蚀后膨胀dst = open()=dilate(erode()) 去掉小点
//闭操作-close  先膨胀后腐蚀bin2
//形态学梯度-Morphological_Granent 膨胀减去腐蚀
//顶帽 - 原图像与开图像之间的差值图像
//黑帽 - 闭操作图像与原图像之间的差值图像
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;
char OUT_WIN[] = "output image";

int main(int argc, char* argv)
{
  Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);
    Mat dst;
    Mat kernel = getStructuringElement(MORPH_RECT,Size(5,5),Point(-1,-1));
    morphologyEx(src,dst,CV_MOP_BLACKHAT,kernel);
    imshow(OUT_WIN,dst);

    waitKey(0);
    return 0;
}
