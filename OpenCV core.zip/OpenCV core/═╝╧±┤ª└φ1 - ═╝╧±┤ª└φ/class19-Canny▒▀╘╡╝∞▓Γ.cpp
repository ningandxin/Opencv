//Canny边缘检测
/*处理流程：
    1. 高斯模糊-GaussianBlur()
    2. 灰度转换-cvtColor
    3. 计算梯度-Sobel/Scharr
    4. 非最大信号抑制
    5. 高低阈值输出二值图像 T1、T2 高于T2都保留、小于T1都丢弃，从高于T2的像素出发，凡是大于T1相互连接都保留
       推荐高低阈值比值为T2：T1 = 3:1/2:1
*/
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;
Mat gaussian_src,gray_src,dst,edge_out,src;
int t1_value = 8;
int t1_max = 255;
void Canney_Demo(int,void*)
{
//    blur(gray_src,gray_src,Size(3,3),Point(-1,-1));
   Canny(gray_src,dst,t1_value,t1_value*3);

//   dst.create(src.size(),src.type());
//   src.copyTo(dst,edge_out);
   imshow("dst",dst);
}
int main(int argc, char* argv)
{

    src = imread("C:\\Users\\LXN\\Desktop\\photo\\2.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);

    namedWindow("dst",WINDOW_AUTOSIZE);
    GaussianBlur(src,gaussian_src,Size(3,3),0,0);
    cvtColor(gaussian_src,gray_src,CV_BGR2GRAY);
    createTrackbar("Threshold :","dst",&t1_value,t1_max,Canney_Demo);
    Canney_Demo(0,0);

    waitKey(0);
    return 0;

}
