//Laplance算子--二阶导数计算时，边缘处为0值--用拉普拉斯算子进行求二阶求导
/*处理流程：
    高斯模糊-去噪声 GaussianBlur()
    转化为灰度图像 cvtColor()
    拉普拉斯-二阶导数计算 Laplacian()
    取绝对值convertScaleAbs()
    显示结果
*/
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
    Mat gaussian_src,gray_src,dst;
    Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\2.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);

    GaussianBlur(src,gaussian_src,Size(3,3),0);
    cvtColor(gaussian_src,gray_src,CV_BGR2GRAY);

    Laplacian(gray_src,dst,CV_16S,3);
    convertScaleAbs(dst,dst);

    threshold(dst,dst,0,255,THRESH_OTSU|THRESH_BINARY);
    imshow("dst",dst);
    waitKey(0);
    return 0;

}
