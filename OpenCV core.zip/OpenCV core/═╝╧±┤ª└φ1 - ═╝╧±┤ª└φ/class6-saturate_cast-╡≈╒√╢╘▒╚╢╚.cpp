//调整图像亮度和对比度
//像素变换-点操作
//g(i,j) = α*f(i,j)+β
//saturate_cast() 函数
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
    Mat src1,src2 ,dst;
     src1 = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg",-1);
    if(src1.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    cvtColor(src1,src1,CV_BGR2GRAY);
    int height = src1.rows;
    int width = src1.cols;
    float alpha = 1.5;
    float beta = 10;
    imshow("src1",src1);
    Mat m1;
    src1.convertTo(m1,CV_32F);
   dst = Mat::zeros(src1.size(),src1.type());
    for(int row=0;row<height;row++)
    {
        for(int col=0;col<width; col++)
        {
            if(src1.channels() == 1)
            {
                float v = src1.at<uchar>(row,col);
                dst.at<uchar>(row,col) = saturate_cast<uchar>(v*alpha+beta);
            } else if(src1.channels() == 3)
            {
                float b = m1.at<Vec3b>(row,col)[0];
                float g = m1.at<Vec3b>(row,col)[1];
                float r = m1.at<Vec3b>(row,col)[2];
                dst.at<Vec3b>(row,col)[0] = saturate_cast<uchar>(b*alpha + beta);
                dst.at<Vec3b>(row,col)[1] = saturate_cast<uchar>(g*alpha + beta);
                dst.at<Vec3b>(row,col)[2] = saturate_cast<uchar>(r*alpha + beta);
            }
        }
    }

    imshow("output",dst);

    waitKey(0);
    return 0;
}