//Sobel算子  -- 改进版本Scharr
//卷积应用-图像边缘提取
//sobel算子功能集合高斯平滑和微分求导，计算图像灰度的近似梯度（一阶微分梯度）
//图像梯度为G = |Gx| + |Gy|
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
    Mat gau_src,gray_src,dst;
    Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\2.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);
    GaussianBlur(src,gau_src,Size(3,3),0,0);
    cvtColor(gau_src,gray_src,CV_BGR2GRAY);

    Mat xgrad,ygrad;
//    Sobel(gray_src,xgrad,CV_16S,1,0,3);
//    Sobel(gray_src,ygrad,CV_16S,0,1,3);
    Scharr(gray_src,xgrad,CV_16S,1,0);
    Scharr(gray_src,ygrad,CV_16S,0,1);

    convertScaleAbs(xgrad,xgrad);
    convertScaleAbs(ygrad,ygrad);
    imshow("xgard",xgrad);
    imshow("ygrad",ygrad);

    Mat xygrad = Mat(xgrad.size(),xgrad.type());

//    addWeighted(xgrad,0.5,ygrad,0.5,0,xygrad);
//    imshow("xygrad",xygrad);
    int width = xgrad.cols;
    int height = ygrad.rows;
    for(int row=0;row<height;row++)
    {
        for(int col = 0;col < width;col++)
        {
            int xg = xgrad.at<uchar>(row,col);
            int yg = ygrad.at<uchar>(row,col);
            int xy = xg + yg;
            xygrad.at<uchar>(row,col) = saturate_cast<uchar>(xy);
        }
    }
    imshow("xygrad",xygrad);
    waitKey(0);
    return 0;

}
