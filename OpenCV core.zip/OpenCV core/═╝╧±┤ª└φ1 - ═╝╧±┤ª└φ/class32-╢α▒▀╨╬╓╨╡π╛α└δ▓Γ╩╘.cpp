// 点多边形测试
//测试一个点是否在给定的多边形内部，边缘或者外部
//API：pointPolygonTest(输入轮廓，测试点，是否返回距离（如果否，1表示内面，0表示边界，-1表示外部，truw返回距离）)返回double类型
/*演示代码：步骤
    1.构建一张400*400大小的图像，Mat：zero(400,400,CV8UC1)
    2.画上一个六边形的闭合区域 LINE
    3.发现轮廓
    4.对图像的所有像素点作多边形测试，得到距离，归一化后显示
 */
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv;


int main(int argc, char* argv)
{
    const int r = 100;
    Mat src = Mat::zeros(r*4,r*4,CV_8UC1);

    vector<Point2f> vert(6);
    vert[0] = Point(3 * r / 2, static_cast<int>(1.34 * r));
    vert[1] = Point(1 * r , 2 * r);
    vert[2] = Point(3 * r / 2, static_cast<int>(2.866 * r));
    vert[3] = Point(5 * r / 2, static_cast<int>(2.866 * r));
    vert[4] = Point(3 * r , 2 * r);
    vert[5] = Point(5 * r / 2, static_cast<int>(1.34 * r));

    for(int i=0;i <6;i++)
    {
        line(src,vert[i],vert[ (i+1)%6],Scalar(255),3,8,0);
    }
    imshow("src",src);

    vector<vector<Point>> contours;
    vector<Vec4i> hierachy;
    Mat csrc;
    src.copyTo(csrc);
    findContours(csrc,contours,hierachy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(0,0));
    Mat raw_dist = Mat::zeros((csrc.size()),CV_32FC1);  //存储距离矩阵
    for(int row = 0;row<raw_dist.rows;row++)
    {
        for(int col=0;col<raw_dist.cols;col++)
        {
            //pointPolygonTest(输入轮廓，测试点，是否返回距离
            double dist = pointPolygonTest(contours[0],Point2f(static_cast<float>(col),static_cast<float>(row)), true);
            raw_dist.at<float>(row,col) = static_cast<float>(dist);
        }
    }
    double minValue ,maxValue;
    minMaxLoc(raw_dist,&minValue,&maxValue,0,0,Mat());
    Mat drawImg = Mat::zeros(src.size(),CV_8UC3);       //显示距离的矩阵

    for(int row = 0;row<drawImg.rows;row++)
    {
        for(int col=0;col<drawImg.cols;col++) {
            float dsitance = raw_dist.at<float>(row,col);
            if(dsitance >0)
            {
                drawImg.at<Vec3b>(row,col)[0] = (uchar)(abs(dsitance/maxValue)*255);    //距离越大越蓝
            }else if(dsitance < 0)
            {
                drawImg.at<Vec3b>(row,col)[2] = (uchar)(abs(1.0 - dsitance/minValue)*255);   //距离越大越红
            }
            else
            {
                drawImg.at<Vec3b>(row,col)[0] = (uchar)(abs(255 - dsitance));
                drawImg.at<Vec3b>(row,col)[1] = (uchar)(abs(255 - dsitance));
                drawImg.at<Vec3b>(row,col)[2] = (uchar)(abs(255 - dsitance));
            }
        }
    }

    imshow("src",src);
    imshow("drawImg",drawImg);

    waitKey(0);
    return 0;
}
