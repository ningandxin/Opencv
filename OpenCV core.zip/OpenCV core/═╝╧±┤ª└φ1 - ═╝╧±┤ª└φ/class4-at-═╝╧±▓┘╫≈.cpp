//图像操作
//读写像素、修改像素值
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
    Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg",-1);
    if(!src.data)
    {
        printf("image is empty ");
        return -1;
    }
    imshow("src",src);
    Mat gray_src;
    cvtColor(src,gray_src,CV_BGR2GRAY);
    int rows = gray_src.rows;
    int cols = gray_src.cols;
//    for(int i=0;i<rows;i++)
//    {
//        for(int j=0;j<cols;j++ )
//        {
//            int gray = gray_src.at<uchar>(i,j);
//            gray_src.at<uchar>(i,j) = 255-gray;
//        }
//    }
    Mat dst;
    dst.create(src.size(),src.type());
    int nc = src.channels();
    for(int i=0;i<rows;i++)
    {
        for(int j=0;j<cols;j++ )
        {
            if(nc == 1)
            {
                int gray = gray_src.at<uchar>(i,j);
                gray_src.at<uchar>(i,j) = 255-gray;
//                cout <<"nc = 1 "<<endl;
            }
            else if(nc == 3)
            {
                int b = src.at<Vec3b>(i,j)[0];
                int g = src.at<Vec3b>(i,j)[1];
                int r = src.at<Vec3b>(i,j)[2];
                dst.at<Vec3b>(i,j)[0] =  b;
                dst.at<Vec3b>(i,j)[1] =  g;
                dst.at<Vec3b>(i,j)[2] =  r;
//                cout <<"nc = 3 "<<endl;
            }
        }
    }
//    bitwise_not(src,dst);
    imshow("out",dst);
    waitKey(0);
    return 0;
}