//中值滤波:统计排序滤波器 排序 medianBlur(Mat src,Mat dst,ksize)
//双边滤波：bilateralFilter(src,dst,d=15,150,3);
    //均值模糊无法克服边缘像素信息丢失缺陷，原因是均值滤波是基于平均权值
    //高斯模糊部分克服了该缺陷，但是无法完全避免，因为没有考虑像素值的不同
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
   Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\our3.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);
    Mat dst1,dst2;


//    bilateralFilter(src,dst1,10,50,3);
    GaussianBlur(src,dst1,Size(15,15),3);
//    Mat kernel = (Mat_<int>(3,3)<<0,-1,0,-1,5,-1,0,-1,0);
//    filter2D(dst1);
    bilateralFilter(src,dst2,15,100,3);


    imshow("dst",dst1);
    imshow("dst2",dst2);

    waitKey(0);
    return 0;
}