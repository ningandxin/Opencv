//自定义线性滤波
//卷积概念：将kernel放到像素数组之上，求锚点周围覆盖的像素乘积之和，用来替换锚点覆盖下的像素值
//常见算子：Robert算子、Sobel算子、拉普拉斯算子
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;


int main(int argc, char* argv)
{
    Mat dst;
    Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\2.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);
// Robert X方向
    Mat img_x;
    Mat kernel_x = (Mat_<int>(2,2)<< 1,0,0,-1);
    filter2D(src,img_x,-1,kernel_x,Point(-1,-1),0.0);
// Robert Y方向
    Mat img_y;
    Mat kernel_y = (Mat_<int>(2,2)<< 0,1,-1,0);
    filter2D(src,img_y,-1,kernel_y,Point(-1,-1),0.0);
// Sobel 算子
    Mat sobel_x;
    Mat kernel_Sx = (Mat_<int>(3,3)<< -1,0,1,-2,0,2,-1,0,1);
    filter2D(src,sobel_x,-1,kernel_Sx,Point(-1,-1),0.0);
    Mat sobel_y;
    Mat kernel_Sy = (Mat_<int>(3,3)<< -1,-2,-1,0,0,0,1,2,1);
    filter2D(src,sobel_y,-1,kernel_Sy,Point(-1,-1),0.0);

    // 拉普拉斯算子
    Mat lapulance_x;
    Mat kernel_Lx = (Mat_<int>(3,3)<< 0,-1,0,-1,4,-1,0,-1,0);
    filter2D(src,lapulance_x,-1,kernel_Lx,Point(-1,-1),0.0);
//    normalize(img_x, img_x,255,0,NORM_MINMAX);
//    normalize(img_y,img_y,255,0,NORM_MINMAX);
//    自定义卷积模糊
    int c = 0;
    int index = 1;
    int ksize = 0;
    while(true)
    {
        c = waitKey(500);
        if((char)c ==27)
        {
//            ESC
            break;
        }
        ksize =  3 + 2 * (index % 5);
        Mat kernel = Mat::ones(Size(ksize,ksize),CV_32F) / (float)(ksize * ksize);
        filter2D(src,dst,-1,kernel,Point(-1,-1),0);
        imshow("dst",dst);
        index++;
    }

//    imshow("sobel_y",sobel_y);
    waitKey(0);
    return 0;
}
