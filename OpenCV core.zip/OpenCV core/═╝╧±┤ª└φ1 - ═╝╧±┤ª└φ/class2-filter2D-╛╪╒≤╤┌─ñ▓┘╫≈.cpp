﻿// 矩阵的掩膜操作
// 获取图像像素指针-filter2D
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{
    Mat dst,src;
    src = imread("C:\\Users\\LXN\\Desktop\\photo\\2.jpg",-1);   //image read
    if(!src.data)
    {
        printf("image is empty");
        return -1;
    }
    imshow("image",src);

    double t = getTickCount();          //时间开始

//    int cols = src.cols * src.channels();   //行
//    int offsetx = src.channels();
//    int rows = src.rows ;
//    dst = Mat::zeros(src.size(),src.type());
//    for(int row=1;row<rows-1;row++)
//    {
//        const uchar* previous = src.ptr<uchar>(row -1);
//        const uchar* current = src.ptr<uchar>(row);
//        const uchar* nest = src.ptr<uchar>(row +1);
//        uchar* output = dst.ptr<uchar>(row);    //矩阵指针访问像素
//        for(int col=offsetx;col <cols;col++)
//        {
//            output[col]=saturate_cast<uchar>(5 * current[col]-(current[col-offsetx] + current[col+offsetx] + previous[col] + nest[col]));
//        }
//    }
//

    Mat kernel = (Mat_<char>(3,3)<<0,-1,0,-1,5,-1,0,-1,0);
    filter2D(src,dst,src.depth(),kernel);
    double timeconsume = (getTickCount()-t)/getTickFrequency();
    printf("const %.10f",timeconsume);
    namedWindow("output",CV_WINDOW_AUTOSIZE);
    imshow("output",dst);
    waitKey(0);
    return 0;
}