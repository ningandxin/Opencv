//基于距离变换与分水岭的图像分割
//图像分割的目标是将图像中像素根据一定的规则分为若干个cluster几何，每个集合包含一类像素
//图像分割的算法多数都是无监督学习方法-KMeans
//距离变换常见算法：1.不断膨胀/腐蚀得到 2. 基于倒角距离 分水岭变换算法：基于浸泡理论实现
//API介绍：distanceTranform（输入图像，输出图像，输出层，Dist_L1|Dist_L2,推荐3*3，离散维诺图输出）
/*处理流程：
    1. 将白色背景变成黑色-目的为后面变换做准备
    2. 使用filter2D与拉普拉斯算子实现图像对比度提高，sharp
    3. 转化为二值图像 通过threshold
    4. 距离变换
    5. 对距离变换结果进行归一化到[0~1]之间
    6. 使用阈值，再次二值化，得到标记
    7. 腐蚀得到每个peak  -  erode
    8. 发现轮廓 - findContours
    9. 绘制轮廓 - drawContours
    10 分水岭变换 watershed
    11 对每个分割区域着色输出结果
 */
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv;

int main(int argc, char* argv)
{
    Mat src,src_gray,dst;
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(!src.data)
    {
        printf("image is empty...\n");
        return -1;
    }

//   1. change backgroud    (注意是图像像素操作为Vec3b)
    for (int row = 0; row < src.rows; row++) {
        for (int col = 0; col < src.cols; col++) {
            if (src.at<Vec3b>(row, col) == Vec3b(255, 255, 255)) {
                src.at<Vec3b>(row, col)[0] = 0;
                src.at<Vec3b>(row, col)[1] = 0;
                src.at<Vec3b>(row, col)[2] = 0;
            }
        }
    }
    namedWindow("black background", CV_WINDOW_AUTOSIZE);
    imshow("black background", src);
//  2.  图像锐化 （注意图像锐化为源图像-拉普拉斯边缘图像）
    Mat kernel = (Mat_<float>(3,3) << 1,1,1,1,-8,1,1,1,1);
    Mat imgLaplance;
    Mat sharpenImg = src;
    filter2D(src,imgLaplance,CV_32F,kernel,Point(-1,-1),0,BORDER_DEFAULT);
    src.convertTo(sharpenImg,CV_32F);
    Mat result = sharpenImg - imgLaplance;
    result.convertTo(result,CV_8UC3);
    imgLaplance.convertTo(imgLaplance,CV_8UC3);

//  3.convert to binary （注意：THRESH_OTSU自动寻找阈值）
    Mat binaryImg;
    cvtColor(result,result,CV_BGR2GRAY);
    threshold(result,binaryImg,40,255,THRESH_BINARY|THRESH_OTSU);
//    imshow("binaryImg",binaryImg);
//  4. 距离变换
    Mat dstImg;
    distanceTransform(binaryImg,dstImg,DIST_L1,3,5);
//  5. 归一化
    normalize(dstImg,dstImg,0,1,NORM_MINMAX);
//  6. 使用阈值，再次二值化，得到标记
    threshold(dstImg,dstImg,0.4,1,THRESH_BINARY);

//  7.二值腐蚀  （腐蚀核为8UC1）
    Mat k1 = Mat::zeros(3,3,CV_8UC1);
    erode(dstImg,dstImg,k1,Point(-1,-1));
//    imshow("dstImg",dstImg);
//  8. 发现轮廓 - findContours  （注意findContours（输入为8位））
    Mat dist_8u;
    dstImg.convertTo(dist_8u,CV_8U);
    vector<vector<Point>> contours;
    findContours(dist_8u,contours,RETR_EXTERNAL,CHAIN_APPROX_SIMPLE,Point(0,0));
//  9. 绘制轮廓 - drawContours（drawContours（输入为32位Short型））
    Mat markets = Mat::zeros(src.size(),CV_32SC1);
    for(size_t i=0;i<contours.size();i++)
    {
        drawContours(markets,contours, static_cast<int>(i),Scalar::all(static_cast<int>(i)+1),-1);
    }
    circle(markets,Point(5,5),3,Scalar(255,255,255),-1);

//    10 分水岭变换 watershed
    watershed(src,markets);
    Mat mark = Mat::zeros(markets.size(),CV_8UC1);
    markets.convertTo(mark,CV_8UC1);
    bitwise_not(mark,mark,Mat());

//    11 对每个分割区域着色输出结果
    vector<Vec3b> colors;
    for(size_t i=0;i<contours.size();i++)
    {
        int r = theRNG().uniform(0,255);
        int g = theRNG().uniform(0,255);
        int b = theRNG().uniform(0,255);
        colors.push_back(Vec3b((uchar)b,(uchar)g,(uchar)r));
    }
    dst = Mat::zeros(markets.size(),CV_8UC3);
    for(int row=0;row<dst.rows;row++)
    {
        for(int col = 0; col < dst.cols; col++)
        {
            int index = markets.at<int>(row,col);
            if(index>0 && index <= static_cast<int>(contours.size()))
            {
                dst.at<Vec3b>(row,col) = colors[index-1];
            }
            else
            {
                dst.at<Vec3b>(row,col) = Vec3b(0,0,0);
            }
        }
    }
    imshow("dst",dst );
    waitKey(0);
    return 0;
}
