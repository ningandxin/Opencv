//直方图均衡化 - 提高图像的对比度，拉伸图像灰度值范围
//直方图：假设图像数据像素值范围为0~14共15个灰度等级，统计得到各个等级出现次数及直方图
//        反映了图像灰度的分布情况
// equalizeHist（输入图像-必须八位单通道，输出图像）
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;


int main(int argc, char* argv)
{
    Mat src,src_gray,dst,map_x,map_y;
    src = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg");
    if(src.empty())
    {
        return -1;
        printf("image1 is empty ");
    }
    imshow("src",src);

    dst.create(src.size(),src.type());
    cvtColor(src,src_gray,CV_BGR2GRAY);
    equalizeHist(src_gray,map_x);
    cvtColor(map_x,dst,CV_GRAY2BGR);

    imshow("dst",dst);

    waitKey(0);
    return 0;

}
