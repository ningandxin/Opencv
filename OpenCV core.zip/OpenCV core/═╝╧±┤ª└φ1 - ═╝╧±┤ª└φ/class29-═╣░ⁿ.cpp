//凸包（convex）：在一个多边形边缘或者内部任意两个点的连线都包含在多边形边界或者内部
//正式定义：包含点集合S中所有点的最小凸多边形成为凸包
/*检测算法：Graham算法
    1. 首先选择Y方向最低的点作为起始点p0
    2. 从p0开始极坐标扫描，一次添加p1...pn（逆时针方向）
    3. 对每个点pi添加到凸包中导致一个左转向（逆时针方向），则添加，否则删除该点
流程：
    1. 首先把图像从RGB转为灰度
    2. 然后再转为二值图像
    3. 通过发现轮廓得到候选点
    4. 凸包API调用
    5. 绘制显示
 */
//convexHull(输入候选点（来自findContours），凸包，顺时针方向，true表示返回点个数)
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv ;
RNG rng(12345);
Mat src,test,dst;
Mat src_gray;
int threshold_value = 18;
int threshold_max = 255;
void Threshold_Callback(int, void *)
{
    Mat bin_output;
    vector<vector<Point>> contours;
    vector<Vec4i> hierachy;
    threshold(src_gray,bin_output,threshold_value,threshold_max,THRESH_BINARY);//转成二值化
    findContours(bin_output,contours,hierachy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(0,0));//发现轮廓点

    vector<vector<Point>> convexs(contours.size());
    for(size_t i=0;i<convexs.size();i++)
    {
        //convexHull(输入候选点（来自findContours），凸包，顺时针方向，true表示返回点个数)
        convexHull(contours[i],convexs[i], false, true);    //凸包
    }
//    绘制
    dst = Mat :: zeros(src.size(),CV_8UC3);
    for(size_t k=0; k<convexs.size();k++)
    {
        Scalar color = Scalar(rng.uniform(0,255),rng.uniform(0,255),rng.uniform(0,255));
        drawContours(dst,contours,k,color,2,8,hierachy,0,Point(0,0));   //描述轮廓
        drawContours(dst,convexs,k,color,2,8,Mat(),0,Point(0,0));
    }
    imshow("dst",dst);
}
int main(int argc, char* argv)
{

    src = imread("D:\\OpenCV core\\class1\\2.png");

    if(src.empty())
    {
        printf("image1 is empty \n");
        return -1;
    }
    namedWindow("src",WINDOW_AUTOSIZE);
    imshow("src",src);
    cvtColor(src,src_gray,CV_BGR2GRAY); //转化为灰度
    blur(src_gray,src_gray,Size(3,3),Point(-1,-1),BORDER_DEFAULT);//模糊去噪
    createTrackbar("tu ","src",&threshold_value,threshold_max, Threshold_Callback);
    Threshold_Callback(0,0);
    waitKey(0);
    return 0;
}
