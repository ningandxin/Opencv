//轮廓周围的矩形和圆形框
/*检测算法：Graham算法
    1. 首先将图像变为二值化图像
    2.发现轮廓，找到图像轮廓
    3.通过相关API在轮廓点上找到最小包含矩阵和圆，旋转矩形与圆
    4.绘制矩形和圆
 */
//approxPolyDP（输入图像，输出图像，任意整数，是否为闭合曲线）
//轮廓周围绘制矩形 boundingRect()得到轮廓周围最小矩形  minAreaRect()得到一个旋转矩形
//轮廓周围绘制圆或椭圆minEnclosingCircle()得到最小区域圆形  fitEllipse()得到最小椭圆

#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv;
RNG rng(12345);
Mat src,test,dst;
Mat src_gray;
int threshold_value = 166;
int threshold_max = 255;

void Contours_Callback(int, void*)
{
    Mat binary_output;
    vector<vector<Point>> contours;
    vector<Vec4i> hierachy;

    threshold(src_gray,binary_output,threshold_value,threshold_max,THRESH_BINARY);
    findContours(binary_output,contours,hierachy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(-1,-1));

    vector<vector<Point>> contours_ploy(contours.size());
    vector<Rect>ploy_rects(contours.size());
    vector<Point2f> ccs(contours.size());
    vector<float>radius(contours.size());

    vector<RotatedRect> minRects(contours.size());
    vector<RotatedRect> myellipse(contours.size());

    for(size_t i=0;i<contours.size();i++) {
        approxPolyDP(Mat(contours[i]), contours_ploy[i], 3, true); //据轮廓得到图像最小矩阵框
        ploy_rects[i] = boundingRect(contours_ploy[i]);         //最小矩阵框
        minEnclosingCircle(contours_ploy[i], ccs[i], radius[i]);  //生成圆心和半径
        if (contours_ploy[i].size() > 5)
        {
        myellipse[i] = fitEllipse(contours_ploy[i]); //得到最小椭圆
        minRects[i] = minAreaRect(contours_ploy[i]); //得到一个旋转矩形
         }
    }

    src.copyTo(dst);
    Point2f pts[4];     //矩阵框四个点的坐标
    for(size_t t=0; t<contours.size();t++)
    {
        Scalar color = Scalar(rng.uniform(0,255),rng.uniform(0,255),rng.uniform(0,255));
//        rectangle(dst,ploy_rects[t],color,2,8);
//        circle(dst,ccs[t],radius[t],color,2,8);

        if(contours_ploy[t].size() >5)
        {
            ellipse(dst,myellipse[t],color,2,8);
            minRects[t].points(pts);
            for(int r=0;r<4;r++)
            {
                line(dst,pts[r],pts[(r+1)%4],color,2,8);//矩阵框四个点连线
            }
        }
    }
    imshow("dst",dst);
    return;
}
int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(src.empty())
    {
        printf("image1 is empty \n");
        return -1;
    }
    namedWindow("src",WINDOW_AUTOSIZE);
    imshow("src",src);
    cvtColor(src,src_gray,CV_BGR2GRAY);
    blur(src_gray,src_gray,Size(3,3),Point(-1,-1));

    createTrackbar("Threshold","src",&threshold_value,threshold_max,Contours_Callback);
    Contours_Callback(0,0);

    waitKey(0);
    return 0;
}
