//膨胀与腐蚀
//形态学操作-基于形状的一系列图像处理操作的合集
//getStructuringElement(int shape,Size ksize,Point anchor)
//dilate(src,dst,kernel) 膨胀 最大值
//erode(src,dst,kernel)  腐蚀 最小值
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;
char OUT_WIN[] = "output image";
Mat src,dst;
int element_size = 3;
int max_size = 21;

void CallBack_demo(int,void*);
int main(int argc, char* argv)
{
  src = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    namedWindow("src",CV_WINDOW_AUTOSIZE);
    imshow("src",src);

    namedWindow(OUT_WIN,CV_WINDOW_AUTOSIZE);
    createTrackbar("Element:",OUT_WIN,&element_size,max_size,CallBack_demo);
    CallBack_demo(0,0);

    waitKey(0);
    return 0;
}
void CallBack_demo(int,void*)
{
    int s = element_size * 2 + 1;
    Mat structureElement = getStructuringElement(MORPH_RECT, Size(s, s), Point(-1, -1));
    dilate(src, dst, structureElement, Point(-1, -1), 1);     //pengzhang
//    erode(src,dst,structureElement);    //fushi
    imshow(OUT_WIN,dst);
    return;
}