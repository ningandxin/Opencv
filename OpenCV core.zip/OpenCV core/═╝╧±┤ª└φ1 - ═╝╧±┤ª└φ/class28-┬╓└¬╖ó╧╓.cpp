//轮廓发现（find contour in your image）
//轮廓发现是基于图像边缘提取的基础寻找对象轮廓的方法，所以边缘提取的阈值选定会影响轮廓发现结果。
//findContours and drawContours 发现轮廓和绘制轮廓
//findContours(输入图像（二值图像），全部发现的轮廓对象，图像的拓扑结构，轮廓返回的模式（返回树），发现方法)
//drawContours(输出图像，全部发现的轮廓现象，轮廓索引号，绘制颜色，绘制线宽，绘制线类型)
/*演示代码步骤
   1. 输入图像转为灰度图像cvtColor()
   2. 使用Canny进行边缘提取，得到的二值图像
   3. 使用findContours寻找轮廓
   4. 使用drawContours绘制轮廓
 */
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv ;
Mat src,test,dst;
int threshold_value = 100;
int threshold_max = 255;
RNG rng;

void Contours_Demo(int, void*)
{
    vector<vector<Point>> contours;
    vector<Vec4i>hierarchy;
    Mat canney_output;
    Canny(src,canney_output,threshold_value,threshold_value*2 ,3, false);
    imshow("canney_output",canney_output);
//findContours(输入图像（二值图像），全部发现的轮廓对象，图像的拓扑结构，轮廓返回的模式（返回树），发现方法)
    findContours(canney_output,contours,hierarchy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(0,0));
    dst = Mat ::zeros(src.size(),CV_8UC3);
    RNG rng(12345);
    for(size_t i = 0; i < contours.size();i++ )
    {
        Scalar color = Scalar(rng.uniform(0,255),rng.uniform(0,255),rng.uniform(0,255));
//      drawContours(输出图像，全部发现的轮廓现象，轮廓索引号，绘制颜色，绘制线宽，绘制线类型)
        drawContours(dst,contours,i,color,2,8,hierarchy,0,Point(0,0));
    }
    imshow("dst",dst);
}
int main(int argc, char* argv)
{
    Mat src_gray;
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(src.empty())
    {
        printf("image1 is empty \n");
        return -1;
    }
    imshow("src",src);

    namedWindow("dst",WAIT_GRANDCHILD);
    cvtColor(src,src_gray,CV_RGB2BGR);
    createTrackbar("contours:","src",&threshold_value,threshold_max,Contours_Demo);
    Contours_Demo(0,0);
    waitKey(0);
    return 0;

}
