//图像的加载、修改、保存
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main()
{
    Mat src = imread("C:\\Users\\LXN\\Desktop\\photo\\1.jpg",-1);   //image read

    if(src.empty())
    {
        printf("image is empty");
        return -1;
    }
    imshow("image",src);
    Mat output_image;
    cvtColor(src,output_image,CV_BGR2HSV);     //Rgb to Gray
    imshow("output windows",output_image);
    imwrite("C:\\Users\\LXN\\Desktop\\photo\\12.jpg",output_image); //image write
    waitKey(0);
    return 0;
}