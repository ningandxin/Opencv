//直方图比较
//对输入的两张图像计算得到直方图H1与H2，归一化到相同的尺度空间，然后通过计算H1与H2之间的距离，得到两个直方图的相似程度
//相关性计算(CV_COMP_CORREL)
//卡方计算（CV_COMP_CHISQR）d(H1,H2)=(H1-H2)^2 /H1
//十字计算（CV_COMP_INTERSECT）
//巴式距离计算（CV_COMP_BHATTACHARYYA）
/*相关API步骤
    1. 首先图像从RGB色彩转换到HSV色彩空间 cvtColor()
    2. 计算图像的直方图，然后归一化到[0~1]之间 calcHist()和normalize()
    3. 使用上述四种比较方法进行比较 compareHist()
 * */
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv ;

string convertToString(double d) {
    ostringstream os;
    if (os << d)
        return os.str();
    return "invalid conversion";
}

int main(int argc, char* argv)
{
    Mat base,test1,test2;
    base = imread("C:\\Users\\LXN\\Desktop\\lena.png");
    test1 = imread("C:\\Users\\LXN\\Desktop\\lena_noise.png");
    test2 = imread("C:\\Users\\LXN\\Desktop\\lena_gray.png");

    if(base.empty())
    {
        return -1;
        printf("image1 is empty \n");
    }
    imshow("test2",test2);
    cvtColor(base,base,CV_BGR2HSV);
    cvtColor(test1,test1,CV_BGR2HSV);
    cvtColor(test2,test2,CV_BGR2HSV);

    int h_bins = 50;
    int s_bins = 60;
    int histSize[] = {h_bins,s_bins};
//    hue varies from 0 to 1/9,saturation from 0 to 255
    float h_ranges[] = {0,180};
    float s_ranges[] = {0,256};
    const float* ranges[] = {h_ranges,s_ranges};

//    use the 0th and 1st channels
    int channels[] = {0,1};
    MatND hist_base,hist_test1,hist_test2;

//    计算直方图
    calcHist(&base,1,channels,Mat(),hist_base,2,histSize,ranges, true, false);
    normalize(hist_base,hist_base,0,1,NORM_MINMAX,-1,Mat());

    calcHist(&test1,1,channels,Mat(),hist_test1,2,histSize,ranges, true, false);
    normalize(hist_test1,hist_test1,0,1,NORM_MINMAX,-1,Mat());

    calcHist(&test2,1,channels,Mat(),hist_test2,2,histSize,ranges, true, false);
    normalize(hist_test2,hist_test2,0,1,NORM_MINMAX,-1,Mat());

//    直方图比较
    double basebase = compareHist(hist_base,hist_base,CV_COMP_BHATTACHARYYA);
    double basetest1 = compareHist(hist_base,hist_test1,CV_COMP_BHATTACHARYYA);
    double basetest2 = compareHist(hist_base,hist_test2,CV_COMP_BHATTACHARYYA);
    double test1test2 = compareHist(hist_test1,hist_test2,CV_COMP_BHATTACHARYYA);

//    cout << test1test2 <<endl;
//  将直方图数据对比放在图像中
    putText(base,convertToString(basebase),Point(50,50),CV_FONT_HERSHEY_COMPLEX,1,Scalar(0,0,255),2,LINE_AA);
    putText(test1,convertToString(basetest1),Point(50,50),CV_FONT_HERSHEY_COMPLEX,1,Scalar(0,0,255),2,LINE_AA);
    putText(test2,convertToString(basetest2),Point(50,50),CV_FONT_HERSHEY_COMPLEX,1,Scalar(0,0,255),2,LINE_AA);

    imshow("base",base);
    imshow("test1",test1);
    imshow("test2",test2);

    waitKey(0);
    return 0;

}
