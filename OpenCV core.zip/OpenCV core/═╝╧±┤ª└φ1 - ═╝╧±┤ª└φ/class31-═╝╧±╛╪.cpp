// 图像距(moments)
//几何距 Mji = ∑（P（x,y）*x*y）其中i+j等于几就叫做几阶距
//中心距 Center（x，y）
//中心归一化距
//API介绍：
//    moments（输入数据，是否为二值图像）
//    contourArea（输入轮廓数据，默认false）
//    arcLength（输入曲线数据、是否为封闭曲线）
/*
 步骤：
    1. 提取图像边缘
    2. 发现轮廓
    3. 计算每个轮廓对象的矩
    4. 计算每个对象的中心、弧长、面积
 */
#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv;
RNG rng(12345);
Mat src,test,dst;
Mat src_gray;
int threshold_value = 80;
int threshold_max = 255;

void moments_Callback(int, void*)
{
    Mat canny_output;
    vector<vector<Point>> contours;
    vector<Vec4i> hierachy;

    Canny(src_gray,canny_output,threshold_value,threshold_value*2,3, false);
    findContours(canny_output,contours,hierachy,RETR_TREE,CHAIN_APPROX_SIMPLE,Point(0,0));

    vector<Moments> contours_monments(contours.size());
    vector<Point2f> ccs(contours.size());
    for(size_t i=0; i < contours.size(); i++)
    {
//        计算每个轮廓的矩
        contours_monments[i] = moments(contours[i]);
//        计算每个图像的圆心、弧长、面积
        ccs[i] = Point(static_cast<float>(contours_monments[i].m10 / contours_monments[i].m00),static_cast<float>(contours_monments[i].m01/contours_monments[i].m00));
    }
    src.copyTo(dst);
//    dst = Mat:: zeros(src.size(),CV_8UC3);
    for(size_t t = 0;t < contours.size();t++ )
    {
        Scalar color = Scalar(rng.uniform(0,255),rng.uniform(0,255),rng.uniform(0,255));
//        打印图像的最小面积、弧长
         printf("contours%d area: %.2f\n arc length : %.2f\n",t,contourArea(contours[t]),arcLength(contours[t], true));
        drawContours(dst,contours,t,color,2,8,hierachy,0,Point(0,0));
        circle(dst,ccs[t],2,color,2,8);
    }
    imshow("dst",dst);
}
int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\1.png");

    if(src.empty())
    {
        printf("image1 is empty \n");
        return -1;
    }
    namedWindow("src",WINDOW_AUTOSIZE);
    imshow("src",src);
    cvtColor(src,src_gray,CV_BGR2GRAY);
    GaussianBlur(src_gray,src_gray,Size(3,3),0,0);

    createTrackbar("Threshold","src",&threshold_value,threshold_max,moments_Callback);
    moments_Callback(0,0);

    waitKey(0);
    return 0;
}
