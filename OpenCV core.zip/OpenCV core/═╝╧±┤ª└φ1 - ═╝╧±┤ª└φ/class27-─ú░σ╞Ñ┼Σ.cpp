//模板匹配（Template Match）
//在整个图像区域发现与给定子图像匹配的小块区域
//需：一个模板图像T和一个待检测图像-源图像S
//工作方法，在待检测图像上，从左到右，从上到下计算模板图像与重叠子图像的匹配度，匹配程度越大，两者相同可能性越大
/*匹配算法：（比较R值大小）
    1. 计算平方不同
    2. 计算相关性
    3. 计算相关系数
    4. 计算归一化平方不同
    5. 计算归一化相关性不同
    6. 计算归一化相关系数不同
 */
//相关API matchTemplate（源图像，模板图像，输出图像（必须单通道浮点数），匹配方法）

#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv ;
Mat src,test,hue,dst;
int match_method = CV_TM_SQDIFF;
int max_track = 5;
void Match_demo(int, void*)
{
    int width = src.cols - test.cols + 1;
    int height = src.rows - test.rows + 1;
    Mat result(width,height,CV_32FC1);

    matchTemplate(src,test,result,match_method);    //模板匹配
    normalize(result,result,1 ,0,NORM_MINMAX);
    Point minLoc,maxLoc;
    double min,max;
    src.copyTo(dst);
    Point temLoc;
    minMaxLoc(result,&min,&max,&minLoc,&maxLoc,Mat());   //最大最小匹配位置
    if(match_method == CV_TM_SQDIFF || match_method == CV_TM_SQDIFF_NORMED)//如果是平方不同的方法是找最小值，其余是最大值
    {
        temLoc = minLoc;
    }else
    {
        temLoc = maxLoc;
    }
    rectangle(dst,Rect(temLoc.x,temLoc.y,test.cols,test.rows),Scalar(255,0,0),2,8);//描述匹配矩阵
    rectangle(result,Rect(temLoc.x,temLoc.y,test.cols,test.rows),Scalar(255,0,0),2,8);

    imshow("dst",dst);
    imshow("result",result);

}
int main(int argc, char* argv)
{

    src = imread("D:\\OpenCV core\\class1\\12.png");
    test = imread("D:\\OpenCV core\\class1\\36.png");

    if(src.empty()||test.empty() )
    {
        printf("image1 is empty \n");
        return -1;
    }
    imshow("src",src);
    imshow("test",test);

    namedWindow("dst",WAIT_GRANDCHILD);
    createTrackbar("match method:","src",&match_method,max_track,Match_demo);
    Match_demo(0,0);

    waitKey(0);
    return 0;

}
