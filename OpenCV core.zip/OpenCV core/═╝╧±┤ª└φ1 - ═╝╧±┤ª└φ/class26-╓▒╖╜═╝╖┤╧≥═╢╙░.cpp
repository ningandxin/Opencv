//直方图反向投影（Back Projection）
//反向投影是反映直方图模型在目标图像中的分布情况
//简单说用直方图模型去目标图像中寻找是否有相似的对象。通常HSV色彩空间的HS两个通道直方图模型
/*相关API步骤
    1. 建立直方图模型
    2. 计算待测图像直方图并映射到模型中
    3.从模型方向计算图像
步骤：
    1.首先加载图像imread()
    2.将图像从RGB色彩空间转换到HSV色彩空间 cvtColor()
    3.计算直方图和归一化 calcHist()和normalize()
    4.Mat与MatND 其中Mat表示二维数组，MatND表示三维或多维数据
    5.计算反向投影图像 - calcBackProject()
 * */

#include <iostream>
#include <opencv2/opencv.hpp>
#include <math.h>
using namespace std;
using namespace cv ;

Mat src,hsv,hue;
int bins = 7;
void Hist_And_Backproject(int, void*)
{
    float range[]={0, 180};
    const float *histRnage = {range};
    Mat h_hist;
    calcHist(&hue,1,0,Mat(),h_hist,1,&bins,&histRnage, true, false);
    normalize(h_hist,h_hist,0,255,NORM_MINMAX,-1,Mat());

    Mat backPrjimg;
    calcBackProject(&hue,1,0,h_hist,backPrjimg,&histRnage,1,true);
    imshow("backPrjimg",backPrjimg);

    //绘制直方图
    int hist_h = 400;
    int hist_w = 400;
    Mat hist_Img;
    hist_Img.create(hist_w,hist_h,CV_8UC3);
    int bin_w = hist_w/bins;
    for(int i=1;i<bins;i++)
    {
        rectangle(hist_Img,
                  Point((i - 1)*bin_w, (hist_h - cvRound(h_hist.at<float>(i - 1) * (400 / 255)))),
//                Point(i*bin_w, (hist_h - cvRound(h_hist.at<float>(i) * (400 / 255)))),
                  Point(i*bin_w, hist_h),
                  Scalar(0, 0, 255), -1);
    }
    imshow("hist_Img",hist_Img);
}
int main(int argc, char* argv)
{
    src = imread("D:\\OpenCV core\\class1\\2.png");

    if(src.empty())
    {
        printf("image1 is empty \n");
        return -1;
    }
    imshow("src",src);
    cvtColor(src,hsv,CV_RGB2HSV);
    hue.create(hsv.size(),hsv.depth());
    int nchannels[] = {0,0};
    mixChannels(&hsv,1,&hue,1,nchannels,1);

//    namedWindow("dst",WINDOW_AUTOSIZE);
    namedWindow("src",WINDOW_AUTOSIZE);

    createTrackbar("Histgram Bins:","src",&bins,180,Hist_And_Backproject);
    Hist_And_Backproject(0,0);

    waitKey(0);
    return 0;

}
