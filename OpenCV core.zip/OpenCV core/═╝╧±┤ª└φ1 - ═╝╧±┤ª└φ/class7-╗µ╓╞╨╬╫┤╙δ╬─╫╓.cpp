﻿//绘制形状与文字
//绘制线、矩形、圆、椭圆等基本几何形状
//随机生成与绘制文本
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;
Mat src;
void MyLines()       //线函数
{
    Point p1 = Point(20,30);
    Point p2;
    p2.x = 300;
    p2.y = 300;
    Scalar color = Scalar(0,0,255);
    line(src,p1,p2,color,1,LINE_8);
}
void MyRectangle()//矩阵框
{
    Rect rect = Rect(50,50,40,25);
    Scalar color = Scalar(0,0,255);
    rectangle(src,rect,color,1,LINE_4);
    Mat roi = Mat(src,rect);
    Mat pImgRect = src.clone();
    rectangle(pImgRect,rect,Scalar(0,255,0),2);
    imshow("roi",roi);
    imwrite("C:\\Users\\LXN\\Desktop\\imahe\\36.png",roi);
}
void MyEllipse()      //椭圆
{
    Scalar color = Scalar(255,0,0);
    ellipse(src,Point(src.cols/2,src.rows/2),Point(src.cols/8,src.rows/8),90,0,360,color,2,LINE_8);
}
void MyCircle() //圆
{
    Scalar color = Scalar(255,255,0);
    Point center = Point(src.cols/2,src.rows/2);
    circle(src,center,150,color,2,8);

}
void MyPolygon()        //多边形
{
    Point pts[1][5];
    pts[0][0] = Point(100,100);
    pts[0][1] = Point(100,200);
    pts[0][2] = Point(200,200);
    pts[0][3] = Point(200,100);
    pts[0][4] = Point(100,100);
    const Point* ppts[] = {pts[0]};
    int npt[] = {5};
    Scalar color = Scalar(255,12,255);

    fillPoly(src,ppts,npt,1,color,8);
}
void RandomLineDemo() {
    RNG rng(12345);
    Point pt1;
    Point pt2;
    Mat bg = Mat::zeros(src.size(), src.type());
    namedWindow("random line demo", CV_WINDOW_AUTOSIZE);
    for (int i = 0; i < 100000; i++) {
        pt1.x = rng.uniform(0, src.cols);
        pt2.x = rng.uniform(0, src.cols);
        pt1.y = rng.uniform(0, src.rows);
        pt2.y = rng.uniform(0, src.rows);
        Scalar color = Scalar(rng.uniform(0, 255), rng.uniform(0, 255), rng.uniform(0, 255));
        if (waitKey(50) > 0) {
            break;
        }
        line(bg, pt1, pt2, color, 1, 8);
        imshow("random line demo", bg);
    }
}

int main(int argc, char* argv)
{
    src = imread("C:\\Users\\LXN\\Desktop\\imahe\\12.png",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }

//    MyEllipse();
    MyRectangle();
    imshow("random ", src);
//    RandomLineDemo();
    imwrite("C:\\Users\\LXN\\Desktop\\imahe\\26.png",src);
    waitKey(0);
    return 0;
}