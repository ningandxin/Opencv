//形态学应用-提取水平与垂直线
// 原理
//1. 输入彩色图像imread（） 2. 转换成灰度图像cvtColor 3. 转换成二值图像-adaptiveThreshold
//4.定义结构元素 5.开操作(腐蚀加膨胀)提取水平和垂直的线

#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;
char OUT_WIN[] = "output image";

int main(int argc, char* argv)
{
  Mat src = imread("C:\\Users\\LXN\\Desktop\\1.png",-1);
    if(src.empty())
    {
        printf("image1 is empty ");
        return -1;
    }
    imshow("src",src);
    Mat gray_src,binImg,temt,dst;
    cvtColor(src,gray_src,CV_BGR2GRAY);//转化为灰度图像
//    imshow("gray_src",gray_src);
    adaptiveThreshold(~gray_src,binImg,255,ADAPTIVE_THRESH_MEAN_C,THRESH_BINARY,15,-2);  //转化为二值图像
//   imshow("binImg",binImg);

    Mat hline = getStructuringElement(MORPH_RECT,Size(src.cols / 16,1),Point(-1,-1));
    Mat vline = getStructuringElement(MORPH_RECT,Size(1,src.rows / 16),Point(-1,-1));

    Mat kernel = getStructuringElement(MORPH_RECT,Size(4,4),Point(-1,-1));

    erode(binImg,temt,kernel);
    dilate(temt,dst,kernel);
//    morphologyEx(binImg,dst,CV_MOP_OPEN,hline);  //开操作
    bitwise_not(dst,dst);  //颜色反转
    imshow("dst",dst);
    waitKey(0);
    return 0;
}
