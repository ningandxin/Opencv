//霍夫圆检测
/*原理：
    从平面坐标到极坐标转换三个参数C(x0,y0,r),其中x0,y0是圆心
    假设平面坐标的任意一个圆上的点，转换到极坐标中：
    C（x0,y0,r）处有最大值
    因为霍夫圆检测对噪声比较敏感，所以首先对图像做中值滤波。
    基于效率原因，opencv中实现霍夫变换圆监测是基于图像梯度实现，分为两步：
    1. 检测边缘，发现可能的圆心
    2. 基于第一步基础上从候选圆心开始计算最佳半径大小
    HoughCircle（输入图像必须是八位，输出结果，方法//Hough_Gradient，dp=1，最短距离，
                   canny 边缘检测低阈值，中心点累加器阈值，最小半径，最大半径）
*/
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv ;

int main(int argc, char* argv)
{

    Mat src_gray,dst;
    Mat src = imread("C:\\Users\\LXN\\Desktop\\1.png",1);
    if(src.empty())
    {
        return -1;
        printf("image1 is empty ");
    }
    imshow("src",src);
    Mat median_src;
    //中值滤波
    medianBlur(src,median_src,5);
    cvtColor(median_src,src_gray,CV_BGR2GRAY);
    //霍夫检测
    vector<Vec3f> pcircles;
    HoughCircles(src_gray,pcircles,CV_HOUGH_GRADIENT,1,10,100,30,5,50);
    src.copyTo(dst);
    for(size_t i=0; i<pcircles.size();i++)
    {
        Vec3f cc = pcircles[i];
        circle(dst,Point(cc[0],cc[1]),cc[2],Scalar(0,0,255),2,LINE_AA);
        circle(dst,Point(cc[0],cc[1]),2,Scalar(255,23,0),2,LINE_AA);
        imshow("dst",dst);
    }

    waitKey(0);
    return 0;

}
